#include "generator.h"
#ifndef UI_H
   #define UI_H

   int getSeed();
   char getMaxLetter();
   int getPositions();
   long getGuesses();
   void clearBuffer();

#endif
