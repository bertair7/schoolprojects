#include <stdio.h>

int main() {
   printf("Greetings from Mars!\n");
   return 0;
}
