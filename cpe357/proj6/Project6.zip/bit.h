#ifndef BIT_H
#define BIT_H

void compressLZW(FILE *input, char *file, int r, int limit);

#endif
