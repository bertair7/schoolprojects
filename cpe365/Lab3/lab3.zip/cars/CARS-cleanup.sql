DROP TABLE cars_data;
DROP TABLE car_names;
DROP TABLE model_list;
DROP TABLE car_makers;
DROP TABLE countries;
DROP TABLE continents;

