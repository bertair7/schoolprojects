INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (18129, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (51991, 1,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (51991, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (51991, 3,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (51991, 4,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83085, 1,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83085, 2,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83085, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83085, 4,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83085, 5,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70723, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13355, 1,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13355, 2,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13355, 3,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52761, 1,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52761, 2,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52761, 3,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52761, 4,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52761, 5,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99002, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99002, 2,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (58770, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (58770, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (58770, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (58770, 4,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (84665, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55944, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55944, 2,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55944, 3,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55944, 4,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55944, 5,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (42166, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16034, 1,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16034, 2,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16034, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16034, 4,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16034, 5,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (25906, 1,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27741, 1,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27741, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27741, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64451, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64451, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64451, 3,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64451, 4,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41028, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73716, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73716, 2,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73716, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73716, 4,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (76667, 1,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (76667, 2,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21040, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21040, 2,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21040, 3,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48332, 1,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48332, 2,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (35011, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95962, 1,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95962, 2,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95962, 3,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95962, 4,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44798, 1,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44798, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44798, 3,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44798, 4,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44798, 5,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (60270, 1,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (60270, 2,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21162, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21162, 2,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21162, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77406, 1,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77406, 2,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77406, 3,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77406, 4,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77406, 5,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32565, 1,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32565, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32565, 3,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (36343, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (36343, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (36343, 3,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (36343, 4,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96619, 1,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86678, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86678, 2,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44330, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44330, 2,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (91937, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (91937, 2,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21545, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21545, 2,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21545, 3,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21545, 4,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21545, 5,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29226, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29226, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29226, 3,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29226, 4,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29226, 5,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (25121, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (25121, 2,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (25121, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (54935, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (54935, 2,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (36423, 1,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83437, 1,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (83437, 2,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49854, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49854, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99994, 1,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99994, 2,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99994, 3,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99994, 4,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (21622, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64861, 1,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64861, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (33456, 1,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (33456, 2,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (75468, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (75468, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (75468, 3,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (56365, 1,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (91192, 1,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (91192, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (91192, 3,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (82056, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (82056, 2,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (82056, 3,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (82056, 4,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27192, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27192, 2,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (27192, 3,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59716, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59716, 2,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59716, 3,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59716, 4,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59716, 5,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (82795, 1,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26240, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (56724, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70796, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70796, 2,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70796, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70796, 4,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37636, 1,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37636, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37636, 3,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (63998, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48981, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48981, 2,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66704, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66704, 2,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66704, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12698, 1,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12698, 2,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12698, 3,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79287, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79287, 2,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79287, 3,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79287, 4,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79287, 5,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55690, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55690, 2,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55690, 3,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (94371, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26148, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26148, 2,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26148, 3,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26148, 4,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11923, 1,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46598, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46598, 2,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46598, 3,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (76951, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85858, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85858, 2,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85858, 3,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85881, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89937, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89937, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89937, 3,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89937, 4,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66227, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66227, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66227, 3,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (66227, 4,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (60240, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (60240, 2,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86085, 1,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86085, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86085, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86085, 4,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67314, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67314, 2,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67314, 3,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67314, 4,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (10013, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26741, 1,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26741, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38157, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38157, 2,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38157, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38157, 4,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (45873, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37540, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37540, 2,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11891, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11891, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11891, 3,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61797, 1,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61797, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61797, 3,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61797, 4,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61797, 5,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52369, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52369, 2,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96430, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64301, 1,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64301, 2,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64301, 3,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (45976, 1,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (45976, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39605, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52013, 1,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52013, 2,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52013, 3,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (52013, 4,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (88626, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53376, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53376, 2,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53376, 3,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53376, 4,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53376, 5,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (15584, 1,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73437, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (24200, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (92252, 1,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (92252, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (92252, 3,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (92252, 4,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (92252, 5,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39685, 1,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39685, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39685, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39685, 4,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61378, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61378, 2,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96761, 1,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96761, 2,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96761, 3,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96761, 4,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26198, 1,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26198, 2,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26198, 3,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26198, 4,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (26198, 5,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78179, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78179, 2,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78179, 3,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78179, 4,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78179, 5,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68890, 1,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (75526, 1,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86162, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86162, 2,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86162, 3,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86162, 4,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86162, 5,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13496, 1,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13496, 2,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13496, 3,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (13496, 4,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (60469, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (50660, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (50660, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64553, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64553, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64553, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64553, 4,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (57784, 1,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (84258, 1,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (84258, 2,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68199, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68199, 2,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78187, 1,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (78187, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (81517, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (81517, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (18951, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20411, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20411, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55494, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (55494, 2,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (42162, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49977, 1,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49977, 2,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49977, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49977, 4,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89638, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89638, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89638, 3,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89638, 4,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73438, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (73438, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96258, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96258, 2,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96258, 3,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96258, 4,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (19258, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12800, 1,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12800, 2,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12800, 3,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12800, 4,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (81368, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (81368, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70655, 1,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70655, 2,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70655, 3,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70655, 4,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (19002, 1,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (19002, 2,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31874, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31874, 2,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31874, 3,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72207, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72207, 2,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (65091, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (42833, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (42833, 2,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (42833, 3,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72949, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72949, 2,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72949, 3,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72949, 4,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (72949, 5,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46248, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38849, 1,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38849, 2,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38849, 3,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38849, 4,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (38849, 5,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86861, 1,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86861, 2,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86861, 3,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (86861, 4,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32701, 1,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32701, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (32701, 3,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89182, 1,  '51-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89182, 2,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89182, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89182, 4,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89182, 5,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68753, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68753, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68753, 3,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68753, 4,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (68753, 5,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39217, 1,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39217, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39217, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39217, 4,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96531, 1,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96531, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96531, 3,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96531, 4,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53922, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53922, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53922, 3,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53922, 4,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64477, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64477, 2,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64477, 3,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64477, 4,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64477, 5,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99058, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99058, 2,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99058, 3,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99058, 4,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (99058, 5,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77032, 1,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77032, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77032, 3,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (77032, 4,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (15286, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (15286, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (15286, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59774, 1,  '51-BLU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59774, 2,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (59774, 3,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (35073, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (35073, 2,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34910, 1,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34910, 2,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34910, 3,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34910, 4,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17685, 1,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17685, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17685, 3,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17685, 4,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (45062, 1,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (45062, 2,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39109, 1,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39109, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37063, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37063, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37063, 3,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (18567, 1,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (18567, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (37586, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (62707, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (62707, 2,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (62707, 3,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (62707, 4,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (28117, 1,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (28117, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (28117, 3,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64574, 1,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64574, 2,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (64574, 3,  '70-W'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (40305, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (40305, 2,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (33060, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (33060, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (33060, 3,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12396, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12396, 2,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12396, 3,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12396, 4,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (12396, 5,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (43103, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39575, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70162, 1,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70162, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70162, 3,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (70162, 4,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (23034, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (23034, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79296, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79296, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79296, 3,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79296, 4,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (79296, 5,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74741, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74741, 2,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74741, 3,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (98806, 1,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (98806, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (98806, 3,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (98806, 4,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (43752, 1,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (47353, 1,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (47353, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (47353, 3,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (47353, 4,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (39829, 1,  '20-BC-L-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (87454, 1,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (87454, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (76663, 1,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (76663, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85492, 1,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85492, 2,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85492, 3,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (85492, 4,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48647, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48647, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (48647, 3,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61008, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61008, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96402, 1,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96402, 2,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (96402, 3,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (35904, 1,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (35904, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49845, 1,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49845, 2,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49845, 3,  '50-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (49845, 4,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46014, 1,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46014, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46014, 3,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46014, 4,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46014, 5,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46876, 1,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46876, 2,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34579, 1,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34579, 2,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34579, 3,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34579, 4,  '26-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17729, 1,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17729, 2,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17729, 3,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17729, 4,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17729, 5,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74952, 1,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74952, 2,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (74952, 3,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61948, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61948, 2,  '70-GON'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61948, 3,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (61948, 4,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41064, 1,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41064, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41064, 3,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17947, 1,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20913, 1,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20913, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20913, 3,  '70-LEM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95514, 1,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95514, 2,  '46-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95514, 3,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (95514, 4,  '51-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (24829, 1,  '20-CA-7.5'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44590, 1,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44590, 2,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44590, 3,  '90-BLU-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44590, 4,  '45-CH'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (44590, 5,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (65165, 1,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (65165, 2,  '90-ALM-I'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (65165, 3,  '70-R'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (65165, 4,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (89588, 1,  '90-BLK-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53240, 1,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (53240, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (46674, 1,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67946, 1,  '90-PEC-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67946, 2,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67946, 3,  '90-APR-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (67946, 4,  '90-LEM-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31233, 1,  '70-M-VA-SM-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31233, 2,  '50-APR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31233, 3,  '50-CHS'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (31233, 4,  '51-BC'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (15904, 1,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (17488, 1,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (97097, 1,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (50512, 1,  '90-APP-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11548, 1,  '45-CO'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (11548, 2,  '90-APIE-10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29908, 1,  '45-VA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29908, 2,  '51-ATW'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29908, 3,  '25-STR-9'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29908, 4,  '70-GA'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (29908, 5,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20127, 1,  '90-BER-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (20127, 2,  '70-M-CH-DZ'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41963, 1,  '50-ALM'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (41963, 2,  '90-CH-PF'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16532, 1,  '50-APP'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16532, 2,  '70-MAR'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16532, 3,  '70-TU'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (16532, 4,  '24-8x10'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34378, 1,  '90-CHR-11'
);

INSERT INTO items(Reciept, Ordinal, Item
)
VALUES (34378, 2,  '45-VA'
);

