-- Ryan Blair rablair@calpoly.edu

source BAKERY-build-customers.sql
source BAKERY-build-goods.sql
source BAKERY-build-receipts.sql
source BAKERY-build-items.sql
