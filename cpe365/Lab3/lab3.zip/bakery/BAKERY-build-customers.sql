INSERT INTO customers(Id, LastName, FirstName
)
VALUES (1, 'LOGAN', 'JULIET'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (2, 'ARZT', 'TERRELL'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (3, 'ESPOSITA', 'TRAVIS'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (4, 'ENGLEY', 'SIXTA'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (5, 'DUNLOW', 'OSVALDO'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (6, 'SLINGLAND', 'JOSETTE'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (7, 'TOUSSAND', 'SHARRON'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (8, 'HELING', 'RUPERT'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (9, 'HAFFERKAMP', 'CUC'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (10, 'DUKELOW', 'CORETTA'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (11, 'STADICK', 'MIGDALIA'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (12, 'MCMAHAN', 'MELLIE'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (13, 'ARNN', 'KIP'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (14, 'SOPKO', 'RAYFORD'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (15, 'CALLENDAR', 'DAVID'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (16, 'CRUZEN', 'ARIANE'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (17, 'MESDAQ', 'CHARLENE'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (18, 'DOMKOWSKI', 'ALMETA'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (19, 'STENZ', 'NATACHA'
);

INSERT INTO customers(Id, LastName, FirstName
)
VALUES (20, 'ZEME', 'STEPHEN'
);

