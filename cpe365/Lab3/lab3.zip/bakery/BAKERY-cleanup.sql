DROP TABLE items;
DROP TABLE receipts;
DROP TABLE goods;
DROP TABLE customers;

