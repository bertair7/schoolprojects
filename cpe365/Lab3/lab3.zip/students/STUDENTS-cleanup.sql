DROP TABLE teachers;
DROP TABLE list;

