INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('MACROSTIE', 'MIN', 101
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('COVIN', 'JEROME', 102
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('MOYER', 'OTHA', 103
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('NIBLER', 'JERLENE', 104
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('MARROTTE', 'KIRK', 105
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('TARRING', 'LEIA', 106
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('URSERY', 'CHARMAINE', 107
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('ONDERSMA', 'LORIA', 108
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('KAWA', 'GORDON', 109
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('SUMPTION', 'GEORGETTA', 110
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('KRIENER', 'BILLIE', 111
);

INSERT INTO teachers(LastName, FirstName, Classroom
)
VALUES ('SUGAI', 'ALFREDA', 112
);

