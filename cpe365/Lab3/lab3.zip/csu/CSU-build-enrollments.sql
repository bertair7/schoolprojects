INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1956,384,123
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1957,432,151
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1958,422,178
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1959,443,184
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1960,414,191
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1961,434,203
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1962,495,230
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1963,533,262
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1964,518,238
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1965,457,210
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1966,492,233
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1967,560,281
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1968,684,358
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1969,790,475
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1970,1036,852
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1971,1757,1495
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1972,2263,1941
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1973,2719,2296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1974,2847,2268
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1975,2982,2295
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1976,3070,2338
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1977,3107,2322
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1978,2927,2239
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1979,2956,2219
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1980,3115,2328
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1981,3220,2358
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1982,3256,2403
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1983,3326,2470
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1984,3501,2547
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1985,3720,2760
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1986,4183,3033
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1987,4494,3312
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1988,4810,3602
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1989,5117,3877
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1990,5300,3845
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1991,5440,4146
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1992,5313,4219
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1993,5178,4158
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1994,5029,4057
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1995,5121,4179
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1996,5256,4394
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1997,5445,4585
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1998,5578,4703
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,1999,6059,5108
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,2000,6383,5358
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,2001,7027,5914
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,2002,7577,6410
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,2003,7597,6358
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (1,2004,7470,6330
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (2,2002,771,562
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (2,2003,1606,1312
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (2,2004,2092,1706
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1935,680,654
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1936,640,641
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1937,628,621
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1938,754,692
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1939,847,772
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1940,806,742
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1941,654,594
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1942,464,390
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1943,284,228
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1944,314,249
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1945,478,375
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1946,950,881
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1947,1160,1066
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1948,1254,1113
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1949,1506,1330
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1950,1474,1289
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1951,1328,1142
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1952,1424,1215
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1953,1532,1312
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1954,1848,1619
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1955,2212,1944
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1956,2672,2363
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1957,3068,2699
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1958,3300,2811
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1959,3284,2845
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1960,3329,2873
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1961,3469,3049
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1962,3785,3304
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1963,4111,3607
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1964,5026,4447
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1965,5734,5156
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1966,6426,5835
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1967,7392,6759
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1968,8040,7431
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1969,9114,8712
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1970,10108,9661
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1971,10693,10036
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1972,11671,11112
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1973,12312,11455
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1974,12598,11612
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1975,13138,11875
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1976,12960,11761
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1977,13008,11785
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1978,12938,11706
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1979,13409,12190
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1980,13873,12557
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1981,13975,12581
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1982,13843,12530
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1983,13901,12643
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1984,14029,12668
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1985,14534,13006
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1986,14837,13026
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1987,15274,13331
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1988,15904,13881
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1989,16345,14324
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1990,16209,14241
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1991,15612,13730
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1992,14970,13412
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1993,14482,12876
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1994,14070,12609
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1995,13586,12291
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1996,13731,12477
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1997,14112,12857
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1998,14826,13486
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,1999,15105,13645
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,2000,15788,14232
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,2001,16468,14786
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,2002,15929,14281
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,2003,15365,13861
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (3,2004,15513,14161
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1965,44,38
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1966,135,118
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1967,470,403
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1968,1035,890
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1969,1806,1586
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1970,2652,2262
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1971,3625,2941
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1972,4080,3314
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1973,4908,3847
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1974,5796,4491
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1975,6621,5018
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1976,6456,4786
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1977,6737,4808
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1978,6716,4778
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1979,6972,4909
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1980,7609,5359
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1981,7889,5565
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1982,8064,5761
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1983,7890,5729
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1984,7477,5363
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1985,7273,5245
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1986,7410,4899
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1987,7869,5093
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1988,8142,5236
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1989,8888,5768
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1990,9680,6211
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1991,10200,6594
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1992,10282,6881
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1993,9731,6491
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1994,9672,6452
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1995,9903,6637
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1996,10341,6969
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1997,10700,7071
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1998,12132,7741
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,1999,12487,7888
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,2000,12710,8060
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,2001,12967,8190
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,2002,13244,8581
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,2003,13133,8785
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (4,2004,12359,8403
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1959,313,136
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1960,978,457
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1961,1371,687
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1962,1726,945
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1963,2413,1654
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1964,3890,2860
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1965,4588,3535
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1966,5331,4153
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1967,6753,5253
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1968,8421,6675
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1969,9547,7686
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1970,11158,9149
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1971,12000,9702
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1972,12166,9597
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1973,11680,8905
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1974,11147,8315
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1975,11239,8250
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1976,10789,7938
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1977,10299,7588
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1978,9999,7314
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1979,10062,7459
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1980,10237,7628
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1981,10866,8139
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1982,11269,8467
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1983,11449,8610
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1984,11537,8649
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1985,11727,8681
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1986,11935,8679
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1987,12030,8686
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1988,12188,8799
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1989,12298,8933
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1990,12721,9225
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1991,12670,9250
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1992,12494,9422
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1993,12218,9474
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1994,12246,9568
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1995,12235,9575
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1996,12464,9704
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1997,12518,9755
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1998,12480,9811
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,1999,12276,9680
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,2000,12287,9670
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,2001,12981,10234
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,2002,13400,10610
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,2003,12932,10352
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (5,2004,12460,10194
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1935,1653,1391
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1936,1660,1420
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1937,1718,1429
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1938,1870,1620
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1939,1950,1717
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1940,2146,1828
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1941,1874,1591
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1942,1404,1131
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1943,987,773
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1944,1058,866
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1945,1593,1323
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1946,2782,2391
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1947,2962,2580
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1948,3146,2634
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1949,3289,2783
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1950,3372,2708
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1951,3305,2713
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1952,3422,2796
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1953,3799,3117
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1954,4492,3656
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1955,4844,4087
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1956,5380,4413
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1957,5642,4659
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1958,5853,4683
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1959,5645,4532
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1960,5758,4579
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1961,6079,4813
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1962,6707,5329
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1963,7161,5721
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1964,7896,6374
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1965,8131,6785
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1966,8661,7406
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1967,9588,8187
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1968,10879,9305
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1969,12966,11294
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1970,13712,12334
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1971,14688,12666
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1972,15088,13169
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1973,15287,13135
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1974,15180,13041
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1975,15275,12814
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1976,14759,12394
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1977,14972,12405
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1978,14413,11968
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1979,14568,12114
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1980,15412,12847
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1981,15798,13124
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1982,15839,13349
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1983,15982,13575
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1984,16206,13743
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1985,16694,13882
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1986,17608,14542
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1987,18128,14916
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1988,18841,15306
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1989,19325,15682
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1990,19508,15825
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1991,19332,15975
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1992,18214,15282
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1993,17430,14817
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1994,16979,14587
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1995,17122,14792
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1996,17193,14690
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1997,17776,14880
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1998,17913,15085
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,1999,18135,15297
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,2000,18788,15627
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,2001,19698,16348
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,2002,20546,16843
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,2003,21141,17241
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (6,2004,19703,16986
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1957,349,88
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1958,284,66
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1959,466,180
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1960,1129,606
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1961,1741,968
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1962,2594,1376
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1963,3671,2088
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1964,4971,3149
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1965,6391,4236
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1966,7528,5290
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1967,9032,6438
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1968,10792,7913
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1969,12835,9526
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1970,14213,10656
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1971,15590,11406
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1972,17579,12649
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1973,18858,13327
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1974,20057,14005
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1975,21386,14687
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1976,21283,14610
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1977,21198,14438
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1978,21020,14424
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1979,21635,14886
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1980,22214,15438
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1981,22812,15964
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1982,22689,15889
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1983,22517,15909
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1984,22704,16062
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1985,23227,16383
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1986,23839,16698
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1987,23843,16811
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1988,24437,17208
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1989,24798,17519
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1990,25428,17939
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1991,24764,16925
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1992,23595,16286
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1993,22139,15423
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1994,21839,15414
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1995,22534,15971
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1996,23886,17044
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1997,24522,17826
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1998,25613,18538
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,1999,27215,19839
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,2000,28616,20852
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,2001,30401,22034
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,2002,31844,23038
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,2003,31720,22953
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (7,2004,33079,24395
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1935,338,287
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1936,328,294
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1937,322,296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1938,350,339
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1939,424,401
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1940,432,422
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1941,368,358
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1942,267,266
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1943,159,160
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1944,173,159
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1945,255,239
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1946,652,615
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1947,704,686
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1948,704,674
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1949,751,698
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1950,624,542
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1951,592,498
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1952,653,523
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1953,812,632
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1954,1068,866
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1955,1244,1063
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1956,1404,1168
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1957,1596,1345
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1958,1790,1498
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1959,1828,1542
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1960,2037,1700
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1961,2102,1727
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1962,2391,1951
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1963,2532,2105
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1964,2883,2446
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1965,3144,2739
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1966,3326,2971
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1967,3751,3460
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1968,4405,4168
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1969,5173,4840
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1970,5672,5253
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1971,6060,5428
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1972,6606,5955
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1973,7053,6458
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1974,7175,6591
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1975,7203,6590
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1976,7048,6422
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1977,7234,6573
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1978,7076,6475
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1979,7186,6587
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1980,7258,6618
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1981,7145,6565
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1982,6876,6442
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1983,6285,5896
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1984,6010,5596
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1985,6053,5674
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1986,5844,5290
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1987,6222,5637
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1988,6753,6240
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1989,7355,6792
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1990,7652,7103
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1991,7779,7220
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1992,7623,7218
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1993,6887,6420
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1994,7029,6626
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1995,7374,6989
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1996,7545,7159
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1997,7420,7038
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1998,7409,7091
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,1999,7440,7020
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,2000,7313,6838
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,2001,7277,6775
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,2002,7553,6992
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,2003,7585,7030
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (8,2004,7367,6859
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1949,432,263
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1950,1058,695
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1951,1964,1112
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1952,2344,1295
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1953,3194,1705
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1954,4189,2344
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1955,5568,3217
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1956,7056,4271
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1957,8304,5184
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1958,9282,5947
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1959,9081,6234
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1960,10001,6795
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1961,11124,7592
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1962,12648,8608
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1963,14710,9954
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1964,17012,11652
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1965,18800,13181
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1966,20369,14550
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1967,23088,16090
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1968,25757,18361
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1969,26611,19027
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1970,26888,19854
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1971,28540,19954
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1972,29410,20086
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1973,30185,20632
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1974,30953,20884
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1975,32210,21729
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1976,31703,21706
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1977,32164,22018
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1978,30550,21221
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1979,30229,21137
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1980,30668,21413
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1981,31118,21972
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1982,31181,22237
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1983,30846,22130
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1984,30546,21803
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1985,32007,22917
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1986,33176,23562
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1987,34194,24187
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1988,34045,24167
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1989,32729,23012
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1990,33543,23724
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1991,31633,22203
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1992,28758,20539
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1993,26242,19113
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1994,25749,19022
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1995,25920,19252
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1996,26682,19754
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1997,27151,20229
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1998,27861,20919
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,1999,29387,22274
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,2000,30125,23094
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,2001,32693,25129
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,2002,33745,25865
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,2003,33363,25639
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (9,2004,32758,25418
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1947,238,229
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1948,1857,1025
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1949,2937,1784
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1950,3696,2307
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1951,4051,2378
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1952,4608,2675
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1953,6044,3075
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1954,7257,3781
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1955,8424,4351
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1956,8910,4713
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1957,10061,5416
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1958,12176,6396
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1959,13648,7693
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1960,14185,8742
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1961,15863,9894
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1962,17239,10562
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1963,18649,11371
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1964,19873,12021
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1965,18652,11436
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1966,19252,11934
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1967,18433,12452
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1968,19619,13441
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1969,21030,14684
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1970,21423,15348
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1971,22486,15225
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1972,22922,15281
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1973,22884,14993
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1974,23103,15026
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1975,24072,15625
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1976,23479,15229
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1977,23531,15277
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1978,22214,14344
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1979,21202,13757
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1980,20820,13536
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1981,21024,13909
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1982,20291,13603
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1983,19389,13167
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1984,19063,12906
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1985,19670,13245
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1986,20070,13359
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1987,19913,13249
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1988,20054,13360
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1989,20029,13426
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1990,20746,13961
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1991,19933,13124
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1992,18497,12527
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1993,17369,11792
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1994,17750,12296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1995,17723,12340
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1996,18273,12671
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1997,18818,13039
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1998,19305,13382
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,1999,19198,13337
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,2000,19317,13446
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,2001,20191,14205
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,2002,20582,14713
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,2003,20015,14696
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (10,2004,19190,14377
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1994,422,468
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1995,362,451
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1996,351,446
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1997,379,492
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1998,433,575
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,1999,542,684
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,2000,597,719
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,2001,561,764
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,2002,637,809
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,2003,657,868
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (11,2004,704,872
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,1995,717,672
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,1996,1312,1286
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,1997,1577,1533
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,1998,1936,1825
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,1999,2228,2114
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,2000,2539,2428
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,2001,2983,2839
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,2002,3484,3287
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,2003,3702,3570
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (12,2004,3710,3578
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1956,1624,646
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1957,2737,1308
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1958,3658,1856
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1959,4598,2596
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1960,6048,3875
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1961,7256,4828
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1962,8594,5833
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1963,9944,6805
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1964,12068,8538
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1965,12754,9408
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1966,13782,10339
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1967,15687,11684
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1968,17724,13471
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1969,20401,15639
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1970,22623,17843
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1971,24080,18065
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1972,24383,18281
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1973,24518,17990
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1974,25141,18171
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1975,26820,18995
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1976,26454,18730
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1977,27312,19106
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1978,26934,18856
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1979,27434,19405
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1980,27430,19498
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1981,26733,19002
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1982,27486,19743
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1983,27167,19654
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1984,27641,19800
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1985,28453,20402
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1986,29328,20903
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1987,29260,20843
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1988,30762,21763
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1989,30349,21334
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1990,30617,21437
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1991,30004,21135
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1992,27834,19590
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1993,26048,18380
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1994,23976,17123
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1995,24962,17890
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1996,26590,19084
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1997,27086,19554
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1998,27054,19615
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,1999,27723,20215
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,2000,29003,21296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,2001,31565,23135
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,2002,33028,24353
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,2003,32702,24134
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (13,2004,31674,23485
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1947,386,400
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1948,404,432
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1949,427,431
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1950,379,378
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1951,317,323
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1952,386,417
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1953,405,440
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1954,361,400
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1955,373,403
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1956,468,491
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1957,760,783
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1958,1193,1194
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1959,1630,1628
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1960,2095,2051
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1961,2631,2539
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1962,3236,3104
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1963,3692,3498
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1964,4252,4037
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1965,4680,4463
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1966,5172,4882
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1967,5730,5390
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1968,6789,6345
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1969,7577,7183
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1970,8433,7835
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1971,9607,8754
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1972,10207,9079
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1973,10128,8746
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1974,10801,9249
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1975,12188,10228
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1976,12889,10793
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1977,13497,11147
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1978,13845,11336
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1979,14430,11853
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1980,15478,12745
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1981,15317,12574
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1982,15869,13055
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1983,16071,13199
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1984,16486,13286
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1985,16735,13440
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1986,17222,13649
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1987,17773,13974
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1988,18292,14395
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1989,18959,14879
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1990,18982,14934
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1991,18471,14482
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1992,17241,13533
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1993,16336,12821
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1994,15909,12561
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1995,16177,12933
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1996,16278,13111
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1997,16772,13613
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1998,17200,14097
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,1999,17616,14296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,2000,18085,14813
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,2001,18648,15467
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,2002,19232,15969
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,2003,18932,15986
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (14,2004,18390,15528
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1947,414,162
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1948,1044,610
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1949,1528,912
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1950,1894,1105
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1951,1942,1027
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1952,2262,963
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1953,2868,1419
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1954,3537,1925
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1955,4404,2588
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1956,5152,3001
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1957,5788,3406
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1958,6207,3671
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1959,6144,3880
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1960,6120,4009
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1961,6186,4251
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1962,7318,4791
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1963,8241,5362
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1964,9119,6192
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1965,9660,6752
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1966,10504,7570
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1967,12062,8980
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1968,13588,10491
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1969,14654,11962
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1970,15807,12639
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1971,17432,14146
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1972,17844,14670
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1973,18606,15002
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1974,19656,15225
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1975,20502,15848
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1976,20173,15611
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1977,20590,15919
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1978,20158,15682
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1979,20821,16217
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1980,21873,17050
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1981,21632,16958
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1982,21521,16937
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1983,21509,17030
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1984,22022,17338
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1985,22930,17700
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1986,23411,17758
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1987,23821,17945
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1988,24768,18589
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1989,25213,19000
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1990,25751,19442
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1991,25358,19019
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1992,23888,18103
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1993,22678,17308
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1994,22286,17048
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1995,22352,17194
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1996,22776,17593
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1997,23027,17885
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1998,23340,18261
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,1999,24207,18801
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,2000,25396,19701
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,2001,26596,20652
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,2002,27759,21529
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,2003,27652,21698
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (15,2004,27494,21717
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1965,290,249
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1966,588,515
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1967,923,807
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1968,1294,1128
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1969,1825,1611
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1970,2234,2003
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1971,2422,2151
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1972,2613,2268
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1973,3039,2592
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1974,3489,2843
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1975,3962,3148
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1976,4002,3086
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1977,4294,3222
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1978,4122,3038
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1979,4091,3030
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1980,4508,3312
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1981,4719,3504
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1982,4908,3689
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1983,5239,3955
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1984,5661,4302
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1985,6391,4782
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1986,7212,5346
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1987,8160,6095
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1988,9362,7099
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1989,10494,7255
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1990,11442,8098
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1991,12019,8709
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1992,11898,8953
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1993,11644,8950
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1994,11429,8832
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1995,11514,8927
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1996,11993,9353
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1997,12989,10088
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1998,13471,10553
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,1999,14168,11035
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,2000,14917,11548
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,2001,15797,12213
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,2002,16298,12629
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,2003,16034,12587
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (16,2004,15659,12637
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1935,1343,1287
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1936,1449,1382
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1937,1670,1616
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1938,1958,1896
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1939,1986,1916
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1940,1914,1748
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1941,1588,1404
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1942,1244,1126
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1943,860,742
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1944,1089,972
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1945,1918,1622
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1946,3636,3191
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1947,4278,3759
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1948,4440,3811
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1949,4712,4002
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1950,4268,3536
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1951,4134,3262
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1952,4494,3567
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1953,5164,4024
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1954,5782,4614
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1955,6868,5429
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1956,8146,6121
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1957,8579,6458
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1958,9030,6652
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1959,9748,7208
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1960,10967,8166
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1961,12169,9127
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1962,13444,10203
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1963,14229,10954
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1964,15940,12165
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1965,16713,12826
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1966,18074,14211
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1967,19984,15724
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1968,21951,17683
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1969,23293,18860
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1970,25380,20247
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1971,26151,20184
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1972,28869,21758
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1973,29861,22517
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1974,30878,23297
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1975,31281,23782
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1976,30158,22715
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1977,30424,22697
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1978,30182,22567
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1979,31398,23896
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1980,33219,25033
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1981,32760,24698
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1982,31162,23713
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1983,31862,24748
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1984,33045,25487
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1985,33976,25868
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1986,34837,26219
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1987,36017,26819
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1988,35937,26621
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1989,35649,26446
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1990,35125,26354
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1991,32572,23969
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1992,29706,22099
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1993,27493,20925
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1994,27886,21458
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1995,29025,22427
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1996,29740,23075
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1997,30177,23434
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1998,30898,24144
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,1999,31040,24261
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,2000,31641,24728
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,2001,33377,26371
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,2002,33288,26723
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,2003,32296,25965
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (17,2004,31563,25687
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1935,1554,1376
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1936,1484,1349
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1937,1606,1454
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1938,2022,1834
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1939,2380,2168
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1940,2158,1969
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1941,1706,1506
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1942,1271,1025
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1943,914,722
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1944,936,757
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1945,1356,1135
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1946,2646,2422
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1947,3404,2882
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1948,4458,3325
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1949,5222,3865
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1950,5386,4081
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1951,5598,4070
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1952,5829,4191
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1953,6526,4611
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1954,7498,5271
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1955,8068,5543
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1956,9046,6220
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1957,9765,6640
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1958,10785,7057
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1959,11283,7689
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1960,11743,8533
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1961,12569,9467
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1962,13925,10422
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1963,15344,11537
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1964,15060,11592
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1965,15723,11921
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1966,17977,13635
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1967,17758,13585
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1968,17644,13285
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1969,17858,13688
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1970,18264,14446
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1971,18910,14152
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1972,20883,15848
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1973,21431,16228
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1974,21257,15850
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1975,23605,17343
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1976,22985,16727
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1977,23851,17385
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1978,23416,17128
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1979,23646,17377
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1980,24031,17640
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1981,23846,17355
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1982,24130,17672
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1983,23645,17544
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1984,23871,17671
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1985,24782,18115
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1986,25574,18737
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1987,26346,19141
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1988,27817,20207
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1989,28826,20637
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1990,28959,20522
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1991,27281,19341
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1992,26051,18397
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1993,25151,18161
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1994,25750,18780
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1995,26595,19596
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1996,27231,20124
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1997,26671,19654
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1998,27029,20051
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,1999,27348,20267
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,2000,26301,19623
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,2001,26585,19779
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,2002,28128,21145
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,2003,28932,21955
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (18,2004,28299,21840
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1935,1717,1638
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1936,1768,1682
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1937,1939,1861
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1938,2186,2076
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1939,2556,2447
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1940,2650,2513
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1941,2742,2038
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1942,2096,1532
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1943,1432,995
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1944,1464,1219
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1945,2307,2273
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1946,4371,4099
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1947,5098,4779
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1948,5836,5439
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1949,6891,6461
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1950,5915,5424
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1951,6239,5532
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1952,6662,5928
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1953,7773,6904
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1954,7854,7157
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1955,9523,8249
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1956,10826,8971
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1957,11842,9588
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1958,12853,10170
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1959,13932,10739
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1960,14468,11592
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1961,15784,12587
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1962,17256,13695
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1963,18930,14836
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1964,19847,15496
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1965,19810,15306
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1966,21379,16491
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1967,22412,17464
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1968,22883,18316
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1969,23654,18758
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1970,24340,19074
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1971,25774,19383
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1972,27247,20177
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1973,27306,20197
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1974,26357,19337
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1975,27221,19683
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1976,26662,19113
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1977,27337,19623
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1978,26128,18875
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1979,25299,18417
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1980,24626,18035
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1981,24319,17694
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1982,24792,18174
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1983,24454,18093
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1984,24517,18071
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1985,25291,18522
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1986,26199,19090
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1987,26726,19470
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1988,28142,20484
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1989,29206,21387
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1990,29879,21649
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1991,29533,21060
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1992,27432,19631
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1993,26192,18858
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1994,25519,18620
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1995,25183,18428
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1996,25414,18807
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1997,25981,19292
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1998,26111,19075
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,1999,26303,19259
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,2000,25989,19071
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,2001,27621,20201
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,2002,29706,21614
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,2003,28866,21027
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (19,2004,28529,21140
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1947,2109,2154
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1948,2493,2582
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1949,2807,2925
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1950,2436,2545
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1951,2098,2192
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1952,2085,2215
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1953,2177,2342
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1954,2675,2872
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1955,3090,3260
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1956,3749,3888
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1957,4031,4130
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1958,4065,4042
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1959,4236,4129
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1960,4555,4484
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1961,4996,4913
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1962,5637,5489
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1963,6102,5934
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1964,6680,6539
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1965,6928,6804
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1966,7461,7457
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1967,8196,8102
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1968,9439,9303
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1969,10835,10702
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1970,11818,11777
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1971,11693,11437
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1972,11773,11566
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1973,12792,12430
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1974,14099,13606
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1975,14780,14230
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1976,14808,14066
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1977,15220,14248
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1978,15339,14213
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1979,15720,14500
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1980,15856,14558
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1981,16137,14760
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1982,15293,14099
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1983,15335,14168
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1984,15764,14437
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1985,15867,14378
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1986,15545,14060
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1987,15904,14290
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1988,16270,14566
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1989,17295,15387
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1990,17267,15476
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1991,17001,15211
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1992,15610,14111
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1993,14956,13618
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1994,15063,13760
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1995,15703,14456
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1996,16394,15148
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1997,16143,14988
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1998,15736,14598
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,1999,15916,14760
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,2000,16340,15103
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,2001,17552,16272
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,2002,17838,16694
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,2003,17550,16501
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (20,2004,17229,16127
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1990,551,344
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1991,1181,791
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1992,1952,1356
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1993,2452,1762
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1994,2736,1982
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1995,3674,2695
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1996,4410,3236
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1997,4630,3433
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1998,5113,3797
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,1999,5758,4334
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,2000,6223,4709
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,2001,6562,4954
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,2002,7469,5737
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,2003,7495,5770
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (21,2004,7418,5854
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1956,184,71
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1957,254,128
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1958,242,124
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1959,217,115
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1960,231,115
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1961,271,127
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1962,480,276
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1963,695,433
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1964,928,657
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1965,1132,853
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1966,1433,1145
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1967,1986,1634
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1968,2857,2527
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1969,3395,3154
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1970,4122,3866
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1971,5067,4712
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1972,5203,4880
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1973,5640,5150
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1974,5822,5172
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1975,5957,5055
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1976,5850,4903
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1977,5887,4605
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1978,5705,4362
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1979,5570,4276
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1980,5508,4285
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1981,5304,4135
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1982,5463,4274
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1983,5307,4166
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1984,5254,4086
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1985,5450,4124
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1986,5698,4320
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1987,6194,4592
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1988,6629,4987
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1989,7044,5386
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1990,7467,5795
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1991,7549,6006
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1992,6893,5439
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1993,6453,5197
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1994,6581,5317
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1995,6709,5529
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1996,6932,5771
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1997,6985,5882
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1998,6982,5883
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,1999,7073,5978
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,2000,7278,6224
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,2001,7527,6464
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,2002,7911,6810
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,2003,8099,6997
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (22,2004,7865,6778
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1960,779,321
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1961,750,310
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1962,726,296
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1963,761,324
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1964,688,325
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1965,681,464
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1966,923,706
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1967,1197,934
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1968,1656,1347
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1969,2173,1867
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1970,2582,2355
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1971,2610,2357
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1972,2658,2342
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1973,2471,2175
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1974,2716,2302
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1975,2987,2447
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1976,3076,2430
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1977,3284,2513
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1978,3193,2474
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1979,3359,2564
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1980,3721,2860
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1981,3931,3031
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1982,3971,3118
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1983,3920,3106
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1984,3856,3018
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1985,4037,3128
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1986,4393,3392
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1987,4633,3541
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1988,4914,3750
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1989,5154,3993
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1990,5394,4179
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1991,5319,4169
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1992,5396,4266
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1993,5399,4420
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1994,5474,4531
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1995,5542,4635
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1996,5735,4761
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1997,5793,4889
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1998,5974,5092
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,1999,6168,5290
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,2000,6650,5611
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,2001,7074,5874
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,2002,7431,6202
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,2003,7396,6184
);

INSERT INTO enrollments(Campus,Year,TotalEnrollment_AY,FTE_AY
)
VALUES (23,2004,7364,6255
);

