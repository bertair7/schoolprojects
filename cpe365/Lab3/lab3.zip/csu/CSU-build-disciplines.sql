INSERT INTO disciplines(Id,Name
)
VALUES (1,'Agriculture'
);

INSERT INTO disciplines(Id,Name
)
VALUES (2,'Architecture'
);

INSERT INTO disciplines(Id,Name
)
VALUES (3,'Area Studies'
);

INSERT INTO disciplines(Id,Name
)
VALUES (4,'Biological Sciences'
);

INSERT INTO disciplines(Id,Name
)
VALUES (5,'Business and Management'
);

INSERT INTO disciplines(Id,Name
)
VALUES (6,'Communications'
);

INSERT INTO disciplines(Id,Name
)
VALUES (7,'Computer and Info. Sciences'
);

INSERT INTO disciplines(Id,Name
)
VALUES (8,'Education'
);

INSERT INTO disciplines(Id,Name
)
VALUES (9,'Engineering'
);

INSERT INTO disciplines(Id,Name
)
VALUES (10,'Fine and Applied Arts'
);

INSERT INTO disciplines(Id,Name
)
VALUES (11,'Foreign Languages'
);

INSERT INTO disciplines(Id,Name
)
VALUES (12,'Health Professions'
);

INSERT INTO disciplines(Id,Name
)
VALUES (13,'Home Economics'
);

INSERT INTO disciplines(Id,Name
)
VALUES (14,'Interdisciplinary Studies'
);

INSERT INTO disciplines(Id,Name
)
VALUES (15,'Letters'
);

INSERT INTO disciplines(Id,Name
)
VALUES (16,'Library'
);

INSERT INTO disciplines(Id,Name
)
VALUES (17,'Mathematics'
);

INSERT INTO disciplines(Id,Name
)
VALUES (18,'Physical Sciences'
);

INSERT INTO disciplines(Id,Name
)
VALUES (19,'Psychology'
);

INSERT INTO disciplines(Id,Name
)
VALUES (20,'Public Affairs'
);

INSERT INTO disciplines(Id,Name
)
VALUES (21,'Social Sciences'
);

INSERT INTO disciplines(Id,Name
)
VALUES (22,'Undeclared'
);

