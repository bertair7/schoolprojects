INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,1996,1951
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,1996,2042
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,1996,1816
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,1996,1797
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,1996,1818
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,1996,1916
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,1996,1884
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,1996,1824
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,1996,1751
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,1996,2258
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,1996,2009
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,1996,1970
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,1996,1903
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,1996,1950
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,1996,1875
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,1996,1902
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,1996,1978
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,1996,2001
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,1996,2204
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,1996,1720
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,1996,2110
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,1996,1915
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,1997,1951
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,1997,2076
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,1997,1791
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,1997,1812
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,1997,1802
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,1997,1936
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,1997,1923
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,1997,1844
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,1997,1758
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,1997,2294
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,1997,1971
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,1997,1975
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,1997,1903
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,1997,1982
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,1997,1889
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,1997,1932
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,1997,1978
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,1997,2013
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,1997,2228
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,1997,1720
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,1997,2110
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,1997,1915
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,1998,1873
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,1998,2026
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,1998,1813
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,1998,1746
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,1998,1754
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,1998,1858
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,1998,1905
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,1998,1766
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,1998,1679
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,1998,2216
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,1998,1893
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,1998,1892
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,1998,1855
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,1998,1934
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,1998,1825
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,1998,1854
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,1998,1940
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,1998,1935
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,1998,2204
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,1998,1712
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,1998,2032
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,1998,1855
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,1999,1795
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,1999,1990
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,1999,1735
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,1999,1680
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,1999,1700
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,1999,1780
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,1999,1851
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,1999,1700
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,1999,1776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,1999,2138
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,1999,1815
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,1999,1814
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,1999,1777
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,1999,1862
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,1999,1748
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,1999,1776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,1999,1936
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,1999,1869
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,1999,2129
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,1999,1634
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,1999,1978
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,1999,1799
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2000,1795
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2000,2026
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2000,1735
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2000,1725
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2000,1746
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2000,1798
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2000,1861
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2000,1742
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2000,1724
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2000,2138
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2000,1855
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2000,1814
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2000,1795
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2000,1874
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2000,1733
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2000,1776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2000,1822
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2000,1857
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2000,2129
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2000,1706
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2000,2002
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2000,1803
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2001,1801
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2001,2070
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2001,1825
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2001,1767
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2001,1762
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2001,1849
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2001,1861
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2001,1744
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2001,1782
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2001,2194
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2001,1855
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2001,1814
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2001,1795
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2001,1887
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2001,1877
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2001,1776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2001,1826
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2001,1909
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2001,2169
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2001,1796
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2001,2032
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2001,1875
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2002,1801
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2002,2070
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2002,1825
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2002,1767
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2002,1762
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2002,1849
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2002,1861
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2002,1744
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2002,1782
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2002,2194
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2002,1855
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2002,1814
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2002,1795
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2002,1887
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2002,1877
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2002,1776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2002,1826
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2002,1909
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2002,2169
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2002,1796
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2002,2032
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2002,1875
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2003,1945
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (2,2003,1868
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2003,2258
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2003,1989
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2003,1944
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2003,1940
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2003,2009
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2003,2035
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2003,1888
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2003,1968
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2003,2412
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2003,1999
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2003,1958
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2003,1939
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2003,2035
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2003,2075
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2003,2014
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2003,1970
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2003,2059
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2003,2976
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2003,1940
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2003,2370
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2003,2023
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2004,2707
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (2,2004,2794
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2004,3154
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2004,2771
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2004,2706
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2004,2704
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2004,2804
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2004,2863
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2004,2658
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2004,2849
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2004,3240
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2004,2761
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2004,2778
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2004,2811
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2004,2824
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2004,2906
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2004,2936
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2004,2880
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2004,2958
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2004,3974
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2004,2776
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2004,3408
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2004,2807
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2005,3318
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (2,2005,2980
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2005,3370
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2005,2991
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2005,2916
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2005,2986
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2005,2990
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2005,3167
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2005,2864
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2005,3035
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2005,3446
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2005,2999
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2005,3036
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2005,3006
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2005,3072
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2005,3092
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2005,3122
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2005,3128
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2005,3292
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2005,4245
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2005,3062
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2005,3616
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2005,3030
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (1,2006,3387
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (2,2006,2980
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (3,2006,3412
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (4,2006,3011
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (7,2006,2946
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (5,2006,3039
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (6,2006,3010
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (8,2006,3175
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (9,2006,2864
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (10,2006,3080
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (11,2006,3476
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (12,2006,3002
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (13,2006,3042
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (14,2006,3015
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (15,2006,3282
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (16,2006,3092
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (17,2006,3160
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (18,2006,3166
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (19,2006,3296
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (20,2006,4349
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (21,2006,3092
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (22,2006,3648
);

INSERT INTO csu_fees(Campus,Year,CampusFee
)
VALUES (23,2006,3043
);

