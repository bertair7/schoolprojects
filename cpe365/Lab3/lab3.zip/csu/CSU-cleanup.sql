DROP TABLE faculty;
DROP TABLE enrollments;
DROP TABLE discipline_enrollments;
DROP TABLE disciplines;
DROP TABLE degrees;
DROP TABLE csu_fees;
DROP TABLE campuses;

