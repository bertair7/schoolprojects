-- Ryan Blair rablair@calpoly.edu

source CSU-build-Campuses.sql
source CSU-build-csu-fees.sql
source CSU-build-degrees.sql
source CSU-build-disciplines.sql
source CSU-build-discipline-enrollments.sql
source CSU-build-enrollments.sql
source CSU-build-faculty.sql
