DROP TABLE wine;
DROP TABLE grapes;
DROP TABLE appellations;

