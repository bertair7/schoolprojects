INSERT INTO albums(AId,Title,Year,Label,Type
)
VALUES (1,'Le Pop',2008,'Propeller Recordings','Studio'
);

INSERT INTO albums(AId,Title,Year,Label,Type
)
VALUES (2,'A Kiss Before You Go',2011,'Propeller Recordings','Studio'
);

INSERT INTO albums(AId,Title,Year,Label,Type
)
VALUES (3,'A Kiss Before You Go: Live in Hamburg',2012,'Universal Music Group','Live'
);

INSERT INTO albums(AId,Title,Year,Label,Type
)
VALUES (4,'Rockland',2015,'Propeller Recordings','Studio'
);

