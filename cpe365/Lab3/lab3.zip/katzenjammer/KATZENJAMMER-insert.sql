-- Ryan Blair rablair@calpoly.edu

source KATZENJAMMER-build-Albums.sql
source KATZENJAMMER-build-Band.sql
source KATZENJAMMER-build-Songs.sql
source KATZENJAMMER-build-Instruments.sql
source KATZENJAMMER-build-Performance.sql
source KATZENJAMMER-build-Tracklists.sql
source KATZENJAMMER-build-Vocals.sql
