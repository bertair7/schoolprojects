# Ryan Blair
# TR Section

CREATE TABLE campuses (
   Id INTEGER,
   Campus VARCHAR(20),
   Location VARCHAR(20),
   County VARCHAR(30),
   Year INTEGER
);

CREATE TABLE csu-fees (
   Campus INTEGER,
   Year INTEGER,
   CampusFee FLOAT
);

CREATE TABLE degrees (
   Year INTEGER,
   Campus INTEGER,
   Degrees INTEGER
);

CREATE TABLE discipline-enrollments (
   Campus INTEGER,
   Discipline INTEGER,
   Year INTEGER,
   Undergraduate INTEGER,
   Graduate INTEGER
);

CREATE TABLE disciplines (
   Id INTEGER,
   Name VARCHAR(20)
);

CREATE TABLE enrollments (
   Campus INTEGER,
   Year INTEGER,
   TotalEnrollment_AY INTEGER,
   FTE_AY INTEGER
);

CREATE TABLE faculty (
   Campus INTEGER,
   Year INTEGER,
   Faculty INTEGER
);
