# Ryan Blair
# TR Section

CREATE TABLE rooms (
   RoomId VARCHAR(3) UNIQUE,
   roomName VARCHAR(20),
   beds INTEGER,
   bedType VARCHAR(10),
   maxOccupancy INTEGER,
   basePrice FLOAT,
   decor VARCHAR(20)
);

CREATE TABLE reservations (
   Code VARCHAR(20),
   Room VARCHAR(3),
   CheckIn VARCHAR(10),
   CheckOut VARCHAR(10),
   Rate FLOAT,
   LastName VARCHAR(20),
   FirstName VARCHAR(20),
   Adults INTEGER,
   Kids INTEGER
);
