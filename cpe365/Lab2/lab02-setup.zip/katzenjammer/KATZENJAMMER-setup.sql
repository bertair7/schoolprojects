# Ryan Blair
# TR Section

CREATE TABLE albums (
   AId INTEGER UNIQUE,
   Title VARCHAR(20),
   Year INTEGER,
   Label VARCHAR(20)
);

CREATE TABLE band (
   Id INTEGER,
   Firstname VARCHAR(20),
   Lastname VARCHAR(20)
);

CREATE TABLE instruments (
   SongId INTEGER,
   BandmateId INTEGER,
   Instrument VARCHAR(20)
);

CREATE TABLE performance (
   SongId INTEGER, 
   Bandmate INTEGER,
   StagePosition VARCHAR(20)
);

CREATE TABLE songs (
   SongId INTEGER,
   Title VARCHAR(20)
);

CREATE TABLE tracklists (
   AlbumId INTEGER,
   Position VARCHAR(20),
   SongId INTEGER
);

CREATE TABLE vocals (
   SongId INTEGER,
   Bandmate INTEGER,
   Type VARCHAR(20)
);
