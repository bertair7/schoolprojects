# Ryan Blair
# TR Section

CREATE TABLE car-makers (
   Id INTEGER,
   Maker VARCHAR(20),
   FullName VARCHAR(20),
   Country VARCHAR(20)
);

CREATE TABLE car-names (
   MakeId INTEGER,
   Model VARCHAR(20),
   MakeDescription(200)
);

CREATE TABLE cars-data (
   Id INTEGER, 
   MPG INTEGER, 
   Cylinders INTEGER,
   Edispl INTEGER,
   Horsepower INTEGER,
   Weight INTEGER,
   Accelerate INTEGER,
   Year INTEGER
);

CREATE TABLE continents (
   ContId INTEGER,
   Continents VARCHAR(20)
);

CREATE TABLE countries (
   CountryId INTEGER,
   CountryName VARCHAR(20),
   Continent VARCHAR(20)
);

CREATE TABLE model-list (
   ModelId INTEGER,
   Maker VARCHAR(20),
   Model VARCHAR(20)
);

