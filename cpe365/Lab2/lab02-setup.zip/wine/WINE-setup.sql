# Ryan Blair
# TR Section

CREATE TABLE appelations (
   No INTEGER,
   Appelation VARCHAR(20),
   County VARCHAR(20),
   State VARCHAR(20),
   Area VARCHAR(20),
   isAVA INTEGER
);

CREATE TABLE grapes (
   ID INTEGER,
   Grape VARCHAR(20),
   Color VARCHAR(20)
);

CREATE TABLE wine (
   No INTEGER,
   Grape VARCHAR(20),
   Winery VARCHAR(20)
   Appelation VARCHAR(20),
   State VARCHAR(20),
   Name VARCHAR(20),
   Year INTEGER,
   Price FLOAT,
   Score INTEGER,
   Cases INTEGER,
   Drink VARCHAR(20)
);
