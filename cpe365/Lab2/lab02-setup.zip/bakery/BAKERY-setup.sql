# Ryan Blair
# TR Section

CREATE TABLE customers (
   Id INTEGER,
   LastName CHAR(20),
   FirstName CHAR(20)
);

CREATE TABLE goods (
   Id INTEGER,
   Flavor CHAR(20),
   Food CHAR(30),
   Price FLOAT
);

CREATE TABLE items (
   Receipt INTEGER,
   Ordinal INTEGER,
   Item CHAR(20)
);

CREATE TABLE receipts (
   ReceiptNumber INTEGER,
   Date DATE, 
   CustomerId INTEGER
);

