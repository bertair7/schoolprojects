# Ryan Blair
# TR Section

CREATE TABLE marathon (
   Place INTEGER,
   Time VARCHAR(8),
   Pace VARCHAR(5),
   GroupPlace INTEGER,
   Group VARCHAR(10),
   Age INTEGER,
   Sex VARCHAR(6),
   BIBNumber INTEGER,
   FirstName VARCHAR(20),
   LastName VARCHAR(20),
   Town VARCHAR(20),
   State VARCHAR(15)
);
