# Ryan Blair
# TR Section

CREATE TABLE airlines (
   Id INTEGER,
   Airline CHAR(20),
   Abbreviation CHAR(10),
   Country CHAR(20) 
);

CREATE TABLE airports100 (
   City CHAR(20),
   AirportCode CHAR(3),
   AirportName CHAR(20),
   Country CHAR(20),
   CountryAbbrev CHAR(3) 
);

CREATE TABLE flights (
   Airline CHAR(20),
   FlightNo INTEGER,
   SourceAirport CHAR(3),
   DestAirport CHAR(3)
);

