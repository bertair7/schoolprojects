INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('CAR', 'MAUDE', 2, 101
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('KRISTENSEN', 'STORMY', 6, 112
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('VANDERWOUDE', 'SHERWOOD', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('NOGODA', 'ISMAEL', 0, 105
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('DANESE', 'JANEE', 4, 111
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('AMY', 'PATRINA', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('PREHM', 'SHANEL', 0, 104
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GRUNIN', 'EMILE', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GELL', 'TAMI', 0, 104
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('MADLOCK', 'RAY', 4, 110
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('SUDA', 'DARLEEN', 4, 110
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('DROP', 'SHERMAN', 0, 104
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('PINNELL', 'ROBBY', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BROMLEY', 'EVELINA', 1, 103
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('YUEN', 'ANIKA', 1, 103
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BUSTILLOS', 'HILMA', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GOODNOE', 'GAYLE', 4, 111
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BALBOA', 'MEL', 1, 103
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BARTKUS', 'REYNALDO', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GROENEWEG', 'CRYSTA', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HOUTCHENS', 'THEO', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GERSTEIN', 'AL', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('MACIAG', 'CHET', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('SAADE', 'TOBIE', 4, 110
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BRINE', 'FRANKLYN', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HANNEMANN', 'CHANTAL', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BYRUM', 'BENNIE', 0, 105
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('NETZEL', 'JODY', 0, 105
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('VANVLIET', 'COLLIN', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HONES', 'GUILLERMINA', 0, 104
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('FLACHS', 'JEFFRY', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('GRABILL', 'JULIENNE', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('AREHART', 'VERTIE', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('RUNKLE', 'MARCUS', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('MOWATT', 'KITTIE', 0, 105
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HOOSOCK', 'LANCE', 1, 103
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('LEAPER', 'ADRIAN', 4, 111
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('PASSEY', 'RAYLENE', 4, 110
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('NAKAHARA', 'SHERON', 0, 105
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('STIRE', 'SHIRLEY', 6, 112
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('RODDEY', 'CYRUS', 4, 110
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('CRANMER', 'CAREY', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('SCHUTZE', 'LANELLE', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('FULVIO', 'ELTON', 4, 111
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HOESCHEN', 'LYNNETTE', 4, 108
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('SOLOMAN', 'BRODERICK', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('LAPLANT', 'SUMMER', 2, 101
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('LUSKEY', 'BRITT', 4, 108
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('JAGNEAUX', 'ELVIRA', 6, 112
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BIBB', 'SHANAE', 1, 103
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('WIRTZFELD', 'DELORAS', 0, 106
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('RANSLER', 'RODGER', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('NABOZNY', 'CHRISSY', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('ATWOOD', 'BETHEL', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('CHIARAMONTE', 'NOVELLA', 2, 101
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('TRAYWICK', 'KERI', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('BRIGHTBILL', 'ANTONY', 1, 102
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('HUANG', 'TAWANNA', 5, 109
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('SANTORY', 'JORDON', 3, 107
);

INSERT INTO list(LastName, FirstName, Grade, Classroom
)
VALUES ('LARKINS', 'GAYLE', 4, 110
);

