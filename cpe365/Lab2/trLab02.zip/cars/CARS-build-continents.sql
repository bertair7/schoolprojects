INSERT INTO continents(ContId,Continent
)
VALUES (1,'america'
);

INSERT INTO continents(ContId,Continent
)
VALUES (2,'europe'
);

INSERT INTO continents(ContId,Continent
)
VALUES (3,'asia'
);

INSERT INTO continents(ContId,Continent
)
VALUES (4,'africa'
);

INSERT INTO continents(ContId,Continent
)
VALUES (5,'australia'
);

