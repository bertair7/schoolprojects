INSERT INTO songs(SongId,Title
)
VALUES (1,'Overture'
);

INSERT INTO songs(SongId,Title
)
VALUES (2,'A Bar In Amsterdam'
);

INSERT INTO songs(SongId,Title
)
VALUES (3,'Demon Kitty Rag'
);

INSERT INTO songs(SongId,Title
)
VALUES (4,'Tea With Cinnamon'
);

INSERT INTO songs(SongId,Title
)
VALUES (5,'Hey Ho on the Devil''s Back'
);

INSERT INTO songs(SongId,Title
)
VALUES (6,'Wading in Deeper'
);

INSERT INTO songs(SongId,Title
)
VALUES (7,'Le Pop'
);

INSERT INTO songs(SongId,Title
)
VALUES (8,'Der Kapitan'
);

INSERT INTO songs(SongId,Title
)
VALUES (9,'Virginia Clemm'
);

INSERT INTO songs(SongId,Title
)
VALUES (10,'Play My Darling,  Play'
);

INSERT INTO songs(SongId,Title
)
VALUES (11,'To the Sea'
);

INSERT INTO songs(SongId,Title
)
VALUES (12,'Mother Superior'
);

INSERT INTO songs(SongId,Title
)
VALUES (13,'Ain\'t no Thang'
);

INSERT INTO songs(SongId,Title
)
VALUES (14,'A Kiss Before You Go'
);

INSERT INTO songs(SongId,Title
)
VALUES (15,'I Will Dance (When I Walk Away)'
);

INSERT INTO songs(SongId,Title
)
VALUES (16,'Cherry Pie'
);

INSERT INTO songs(SongId,Title
)
VALUES (17,'Land of Confusion'
);

INSERT INTO songs(SongId,Title
)
VALUES (18,'Lady Marlene'
);

INSERT INTO songs(SongId,Title
)
VALUES (19,'Rock-Paper-Scissors'
);

INSERT INTO songs(SongId,Title
)
VALUES (20,'Cocktails and Ruby Slippers'
);

INSERT INTO songs(SongId,Title
)
VALUES (21,'Soviet Trumpeter'
);

INSERT INTO songs(SongId,Title
)
VALUES (22,'Loathsome M'
);

INSERT INTO songs(SongId,Title
)
VALUES (23,'Shepherd\'s Song'
);

INSERT INTO songs(SongId,Title
)
VALUES (24,'Gypsy Flee'
);

INSERT INTO songs(SongId,Title
)
VALUES (25,'God\'s Great Dust Storm'
);

INSERT INTO songs(SongId,Title
)
VALUES (26,'Ouch'
);

INSERT INTO songs(SongId,Title
)
VALUES (27,'Listening to the World'
);

INSERT INTO songs(SongId,Title
)
VALUES (28,'Johnny Blowtorch'
);

INSERT INTO songs(SongId,Title
)
VALUES (29,'Flash'
);

INSERT INTO songs(SongId,Title
)
VALUES (30,'Driving After You'
);

INSERT INTO songs(SongId,Title
)
VALUES (31,'My Own Tune'
);

INSERT INTO songs(SongId,Title
)
VALUES (32,'Badlands'
);

INSERT INTO songs(SongId,Title
)
VALUES (33,'Old De Spain'
);

INSERT INTO songs(SongId,Title
)
VALUES (34,'Oh My God'
);

INSERT INTO songs(SongId,Title
)
VALUES (35,'Lady Gray'
);

INSERT INTO songs(SongId,Title
)
VALUES (36,'Shine Like Neon Rays'
);

INSERT INTO songs(SongId,Title
)
VALUES (37,'Flash in the Dark'
);

INSERT INTO songs(SongId,Title
)
VALUES (38,'My Dear'
);

INSERT INTO songs(SongId,Title
)
VALUES (39,'Bad Girl'
);

INSERT INTO songs(SongId,Title
)
VALUES (40,'Rockland'
);

INSERT INTO songs(SongId,Title
)
VALUES (41,'Curvaceous Needs'
);

INSERT INTO songs(SongId,Title
)
VALUES (42,'Borka'
);

INSERT INTO songs(SongId,Title
)
VALUES (43,'Let it Snow'
);

