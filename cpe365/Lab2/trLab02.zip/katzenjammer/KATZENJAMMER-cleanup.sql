DROP TABLE vocals;
DROP TABLE tracklists;
DROP TABLE performance;
DROP TABLE instruments;
DROP TABLE songs;
DROP TABLE band;
DROP TABLE albums;

