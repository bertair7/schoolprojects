INSERT INTO band(Id,Firstname,Lastname
)
VALUES (1,'Solveig','Heilo'
);

INSERT INTO band(Id,Firstname,Lastname
)
VALUES (2,'Marianne','Sveen'
);

INSERT INTO band(Id,Firstname,Lastname
)
VALUES (3,'Anne-Marit','Bergheim'
);

INSERT INTO band(Id,Firstname,Lastname
)
VALUES (4,'Turid','Jorgensen'
);

