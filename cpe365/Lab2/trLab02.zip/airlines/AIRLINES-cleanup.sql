DROP TABLE flights;
DROP TABLE airports100;
DROP TABLE airlines;

