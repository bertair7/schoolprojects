INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (1,'Zinfandel','Robert Biale','St. Helena','California','Old Kraft Vineyard',2008,44,93,275,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (2,'Zinfandel','Chiarello Family','Napa Valley','California','Giana',2008,35,93,480,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (3,'Zinfandel','Robert Biale','Napa Valley','California','Black Chicken',2008,40,91,2700,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (4,'Zinfandel','Robert Biale','Napa Valley','California','Napa Ranches',2008,38,89,525,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (5,'Zinfandel','Robert Biale','St. Helena','California','Varozza Vineyard',2008,44,88,275,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (6,'Zinfandel','Pedroncelli','Dry Creek Valley','California','Mother Clone',2008,15,88,6000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (7,'Zinfandel','Rutherford Ranch','Napa Valley','California','Zinfandel',2007,18,87,1552,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (8,'Sauvignon Blanc','Altamura','Napa Valley','California','Sauvignon Blanc',2007,48,92,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (9,'Sauvignon Blanc','Capture','Sonoma County','California','Les Pionniers',2009,36,92,360,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (10,'Sauvignon Blanc','Brander','Santa Ynez Valley','California','Cuvee Nicolas',2009,25,91,377,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (11,'Sauvignon Blanc','Capture','California','California','Tradition',2009,30,91,875,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (12,'Sauvignon Blanc','John Anthony','Carneros','California','Church Vineyard',2009,28,91,354,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (13,'Sauvignon Blanc','Peter Michael','Knights Valley','California','L''Apres-Midi',2008,48,91,1260,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (14,'Sauvignon Blanc','Grey Stack','Bennett Valley','California','Rosemary''s Block Dry Stack Vineyard',2009,28,90,700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (15,'Sauvignon Blanc','Round Pond Estate','Rutherford','California','Sauvignon Blanc',2009,26,90,714,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (16,'Sauvignon Blanc','Beckmen','Santa Ynez Valley','California','Sauvignon Blanc',2009,16,89,1500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (17,'Sauvignon Blanc','Beltane Ranch','Sonoma Valley','California','Sauvignon Blanc',2009,23,89,413,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (18,'Sauvignon Blanc','Brander','Santa Ynez Valley','California','Mesa Verde Vineyard',2009,22,89,380,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (19,'Sauvignon Blanc','Cade','Napa Valley','California','Sauvignon Blanc',2008,26,89,5200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (20,'Sauvignon Blanc','Jericho Canyon','Napa Valley','California','Sauvignon Blanc',2009,25,89,370,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (21,'Sauvignon Blanc','John Anthony','Napa Valley','California','Sauvignon Blanc',2009,19,89,3098,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (22,'Sauvignon Blanc','Kenzo','Napa Valley','California','Asatsuyu',2008,60,89,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (23,'Sauvignon Blanc','Madrigal','Napa Valley','California','Estate',2009,25,89,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (24,'Sauvignon Blanc','Joseph Phelps','St. Helena','California','Sauvignon Blanc',2008,32,89,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (25,'Sauvignon Blanc','Sbragia Family','Dry Creek Valley','California','Home Ranch',2009,20,89,1698,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (26,'Sauvignon Blanc','Selene','Carneros','California','Hyde Vineyards',2009,27,89,750,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (27,'Sauvignon Blanc','Brander','Santa Ynez Valley','California','Purisma Mountain',2009,25,88,260,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (28,'Sauvignon Blanc','Cimarone','Happy Canyon of Santa Barbara','California','3CV Grassini Family Vineyards',2009,21,88,270,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (29,'Sauvignon Blanc','Sbragia Family','Dry Creek Valley','California','Schmidt Ranch',2009,24,88,602,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (30,'Sauvignon Blanc','Azur','Rutherford','California','Sauvignon Blanc',2009,24,87,1000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (31,'Sauvignon Blanc','Brander','Santa Ynez Valley','California','Cuvee Natalie',2009,18,87,857,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (32,'Sauvignon Blanc','Brander','Santa Ynez Valley','California','au Naturel',2009,32,87,759,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (33,'Sauvignon Blanc','Handley','Dry Creek Valley','California','Handley Vineyard',2008,15,87,1214,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (34,'Sauvignon Blanc','Imagery','Sonoma Valley','California','Wow Oui',2009,27,87,874,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (35,'Sauvignon Blanc','Koehler','Santa Ynez Valley','California','Sauvignon Blanc',2008,12,87,505,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (36,'Sauvignon Blanc','Pomelo','California','California','Sauvignon Blanc',2009,10,87,50000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (37,'Sauvignon Blanc','Twomey','Napa Valley','California','Sauvignon Blanc',2009,25,87,3326,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (38,'Sauvignon Blanc','White Oak','Russian River Valley','California','Sauvignon Blanc',2008,16,87,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (39,'Sauvignon Blanc','Benziger','Sonoma-Lake Counties','California','Sauvignon Blanc',2009,15,86,20000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (40,'Sauvignon Blanc','Kunde Estate','Sonoma Valley','California','Magnolia Lane',2009,16,86,15000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (41,'Sauvignon Blanc','J. Lohr','Napa Valley','California','Carol''s Vineyard',2009,24,86,2900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (42,'Sauvignon Blanc','Pedroncelli','Dry Creek Valley','California','East Side Vineyards',2009,12,86,5100,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (43,'Sauvignon Blanc','Star Lane','Santa Ynez Valley','California','Sauvignon Blanc',2008,20,86,2800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (44,'Sauvignon Blanc','Angeline','Russian River Valley','California','Sauvignon Blanc',2009,14,85,8500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (45,'Sauvignon Blanc','Manifesto!','North Coast','California','Sauvignon Blanc',2008,12,85,8100,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (46,'Sauvignon Blanc','Mirassou','California','California','Sauvignon Blanc',2008,12,85,42000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (47,'Sauvignon Blanc','No','Lake County','California','Sauvignon Blanc',2008,12,85,4210,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (48,'Cabernet Sauvingnon','Chappellet','Napa Valley','California','Pritchard Hill',2007,135,96,3368,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (49,'Cabernet Sauvingnon','Lewis','Napa Valley','California','Reserve',2007,130,95,1700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (50,'Cabernet Sauvingnon','Neyers','Napa Valley','California','Neyers Ranch - Conn Valley',2007,48,95,575,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (51,'Cabernet Sauvingnon','Ramey','Napa Valley','California','Annum',2007,85,95,1700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (52,'Cabernet Sauvingnon','Round Pond Estate','Rutherford','California','Cabernet Sauvignon',2007,50,94,4018,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (53,'Cabernet Sauvingnon','Carter','Napa Valley','California','Beckstoffer To Kalon Vineyard',2007,125,92,190,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (54,'Cabernet Sauvingnon','Carter','Napa Valley','California','Coliseum Block',2007,125,92,277,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (55,'Cabernet Sauvingnon','Ehlers Estate','St. Helena','California','1886',2007,95,92,800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (56,'Cabernet Sauvingnon','Fontanella Family','Mount Vedeer','California','Cabernet Sauvignon',2007,50,92,650,2010
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (57,'Cabernet Sauvingnon','Janzen','Napa Valley','California','Beckstoffer To Kalon Vineyard',2007,135,92,235,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (58,'Cabernet Sauvingnon','Morlet','Napa Valley','California','Couer de Valee',2007,175,92,250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (59,'Cabernet Sauvingnon','Penche','Napa Valley','California','Cabernet Sauvignon',2006,60,92,354,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (60,'Pinot Noir','Kosta Browne','Russian River Valley','California','Amber Ridge Vineyard',2008,72,95,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (61,'Pinot Noir','Kosta Browne','Russian River Valley','California','Keefer Ranch',2008,72,95,613,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (62,'Pinot Noir','Kosta Browne','Russian River Valley','California','Koplen Vineyard',2008,72,95,792,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (63,'Pinot Noir','Patz & Hall','Russian River Valley','California','Freestone Hill',2007,70,95,245,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (64,'Pinot Noir','Foxen','Santa Maria Valley','California','Julia''s Vineyard',2008,56,94,670,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (65,'Pinot Noir','Paul Hobbs','Napa Valley','California','Carneros Hyde Vineyard',2008,75,94,741,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (66,'Pinot Noir','Kosta Browne','Russian River Valley','California','Pinot Noir',2008,52,94,3632,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (67,'Pinot Noir','Kosta Browne','Santa Lucia Highlands','California','Garys'' Vineyard',2008,72,94,422,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (68,'Pinot Noir','Kosta Browne','Sonoma Coast','California','Kanzler Vineyard',2008,72,94,564,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (69,'Pinot Noir','Lynmar','Russian River Valley','California','Five Sisters',2007,100,94,147,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (70,'Pinot Noir','Kosta Browne','Santa Lucia Highlands','California','Pisoni Vineyard',2008,72,93,115,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (71,'Pinot Noir','Kosta Browne','Santa Lucia Highlands','California','Rosella''s Vineyard',2008,72,93,255,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (72,'Pinot Noir','Landmark','Sonoma Coast','California','Kanzler Vineyard',2008,65,93,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (73,'Pinot Noir','Lynmar','Russian River Valley','California','Valley Bliss Block',2008,70,93,152,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (74,'Pinot Noir','Patz & Hall','Sonoma Coast','California','Pinot Noir',2008,42,93,3103,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (75,'Pinot Noir','Valdez Family','Russian River Valley','California','Lancel Creek Vineyard',2007,55,93,130,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (76,'Pinot Noir','De Loach','Green Valley of Russian River Valley','California','Pinot Noir',2008,45,92,1467,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (77,'Pinot Noir','Kosta Browne','California','California','4-Barrel',2008,72,92,97,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (78,'Pinot Noir','Kosta Browne','Sonoma Coast','California','Gap''s Crown Vineyard',2008,68,92,690,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (79,'Pinot Noir','Kosta Browne','Sonoma Coast','California','Pinot Noir',2008,52,90,3554,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (80,'Pinot Noir','Rusack','Sta. Rita Hills','California','Reserve',2008,40,89,340,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (81,'Pinot Noir','Acacia','California','California','A by Acacia',2008,17,88,58231,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (82,'Pinot Noir','Alma Rosa','Sta. Rita Hills','California','La Encantada Vineyard',2008,43,88,591,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (83,'Pinot Noir','Alma Rosa','Sta. Rita Hills','California','La Encantada Vineyard Clone 667',2008,43,88,358,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (84,'Pinot Noir','Artesa','Carneros','California','Estate Reserve',2007,40,88,3527,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (85,'Pinot Noir','Robert Mondavi','Napa Valley','California','Carneros',2008,28,88,30300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (86,'Pinot Noir','Pfendler','Sonoma Coast','California','Pinot Noir',2008,45,88,400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (87,'Pinot Noir','Roar','Santa Lucia Highlands','California','Garys'' Vineyard',2008,50,88,710,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (88,'Pinot Noir','Rusack','Santa Maria Valley','California','Pinot Noir',2008,36,88,833,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (89,'Pinot Noir','Sequana','Santa Lucia Highlands','California','Sarmento Vineyard',2008,32,88,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (90,'Pinot Noir','Spell','Sonoma Coast','California','Pinot Noir',2008,30,88,170,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (91,'Pinot Noir','Twomey','Santa Barbara County','California','Pinot Noir',2008,30,88,1510,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (92,'Pinot Noir','Alma Rosa','Sta. Rita Hills','California','Pinot Noir',2008,32,87,4651,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (93,'Pinot Noir','Castle Rock','Central Coast','California','Pinot Noir',2008,13,87,36000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (94,'Pinot Noir','V. Sattui','Carneros','California','Henry Ranch',2008,36,87,951,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (95,'Pinot Noir','Sebastiani','Carneros','California','Pinot Noir',2008,24,87,720,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (96,'Pinot Noir','Talbott','Santa Lucia Highlands','California','Kali Hart',2008,21,87,8000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (97,'Pinot Noir','Tudor','Santa Lucia Highlands','California','Pinot Noir',2007,40,87,3965,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (98,'Pinot Noir','Twomey','Sonoma Coast','California','Pinot Noir',2008,50,87,1255,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (99,'Pinot Noir','Castle Rock','Russian River Valley','California','Pinot Noir',2008,18,86,2400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (100,'Pinot Noir','Talbott','Santa Lucia Highlands','California','Sleepy Hollow Vineyard',2008,40,86,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (101,'Pinot Noir','Greg Norman California Estates','Santa Barbara County','California','Pinot Noir',2008,15,85,25000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (102,'Syrah','Chalk Hill','Chalk Hill','California','Syrah',2007,60,94,304,2001
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (103,'Syrah','DuMOL','Russian River Valley','California','Eddie''s Patch',2007,76,92,420,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (104,'Merlot','Mirassou','California','California','Merlot',2007,12,86,43321,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (105,'Malbec','Red Rock','California','California','Reserve',2008,11,86,16281,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (106,'Cabernet Sauvingnon','Darioush','Napa Valley','California','Darius II',2007,225,96,698,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (107,'Cabernet Sauvingnon','Darioush','Napa Valley','California','Cabernet Sauvignon',2007,80,94,8783,2013
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (108,'Cabernet Sauvingnon','Lewis','Napa Valley','California','Hillstone Vineyard',2008,130,94,180,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (109,'Cabernet Sauvingnon','Chimeney Rock','Stags Leap District','California','Tomahawk Vineyard',2007,115,93,958,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (110,'Cabernet Sauvingnon','Chimeney Rock','Stags Leap District','California','Elevage',2007,78,93,1952,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (111,'Cabernet Sauvingnon','Peter Franus','Napa Valley','California','Cabernet Sauvignon',2007,40,92,1369,2013
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (112,'Cabernet Sauvingnon','Turnbull','Napa Valley','California','Cabernet Sauvignon',2007,40,91,10000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (113,'Cabernet Sauvingnon','Pott','Oakville','California','Neruda Brix Vineyard',2008,90,90,73,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (114,'Cabernet Sauvingnon','Beringer','Knights Valley','California','Cabernet Sauvignon',2008,27,88,44500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (115,'Cabernet Sauvingnon','Dry Creek','Dry Creek Valley','California','Cabernet Sauvignon',2007,25,87,15000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (116,'Grenache','Sine Qua Non','Sta. Rita Hills','California','In the Crosshairs Eleven Confessions Vineyard',2006,200,97,202,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (117,'Grenache','Herman Story','California','California','On the Road',2008,36,93,398,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (118,'Grenache','Villa Creek','Paso Robles','California','Garnacha Denner Vineyard',2008,35,91,350,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (119,'Grenache','Beckmen','Santa Ynez Valley','California','Purisma Mountain Vineyard',2008,48,88,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (120,'Grenache','Bella Victorian','Santa Barbara County','California','Romeo',2006,39,87,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (121,'Grenache','Austine Hope','Paso Robles','California','Hope Family Vineyard',2009,42,87,566,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (122,'Grenache','Jemrose','Bennett Valley','California','Foggy Knoll Vineyard',2008,38,87,275,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (123,'Petite Sirah','Alta Colina','Paso Robles','California','Ann''s Block',2008,48,91,123,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (124,'Petite Sirah','Erna Schein','Sonoma County','California','Kick Ranch',2008,48,91,312,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (125,'Petite Sirah','Jaffurs','Santa Barbara County','California','Thompson Vineyard',2009,34,90,501,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (126,'Petite Sirah','Turley','Napa Valley','California','Hayne Vineyard',2008,75,90,350,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (127,'Petite Sirah','JC Cellars','Russian River Valley','California','Sweetwater Springs Vineyard',2008,35,89,340,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (128,'Petite Sirah','Parducci','Mendocino County','California','Petite Sirah',2007,11,85,15340,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (129,'Pinot Noir','A.P.Vin','Santa Lucia Highlands','California','Rosella''s Vineyard',2009,48,95,325,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (130,'Pinot Noir','Siduri','Santa Lucia Highlands','California','Pisoni Vineyard',2009,54,95,364,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (131,'Pinot Noir','A.P.Vin','Sonoma Coast','California','Kanzler Vineyard',2009,48,94,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (132,'Pinot Noir','Loring','Paso Robles','California','Russel Family Vineyard',2009,45,94,250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (133,'Pinot Noir','Loring','Sonoma Coast','California','Durell Vineyard',2009,45,94,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (134,'Pinot Noir','Siduri','Santa Lucia Highlands','California','Garys'' Vineyard',2009,51,94,298,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (135,'Pinot Noir','A.P.Vin','Santa Lucia Highlands','California','Garys'' Vineyard',2009,48,93,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (136,'Pinot Noir','A.P.Vin','Santa Maria Valley','California','Rancho Oliveros Vineyard',2009,48,93,50,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (137,'Pinot Noir','Loring','Green Valley of Russian River Valley','California','Graham Family Vineyard',2009,45,93,150,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (138,'Pinot Noir','Loring','Russian River Valley','California','Pinot Noir',2009,29,93,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (139,'Pinot Noir','Loring','Santa Lucia Highlands','California','Pinot Noir',2009,29,93,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (140,'Pinot Noir','Loring','Santa Lucia Highlands','California','Garys'' Vineyard',2009,45,93,450,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (141,'Pinot Noir','Loring','Sta. Rita Hills','California','Clos Pepe Vineyard',2009,45,93,1000,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (142,'Pinot Noir','A.P.Vin','Russian River Valley','California','Keefer Ranch Vineyard',2009,48,92,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (143,'Pinot Noir','Loring','Green Valley of Russian River Valley','California','Keefer Ranch Vineyard',2009,45,92,400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (144,'Pinot Noir','Loring','Sta. Rita Hills','California','Cargasacchi Vineyard',2009,45,92,175,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (145,'Pinot Noir','Siduri','Santa Lucia Highlands','California','Pinot Noir',2009,29,92,1855,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (146,'Pinot Noir','A.P.Vin','Sta. Rita Hills','California','Clos Pepe Vineyard',2009,48,91,150,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (147,'Pinot Noir','A.P.Vin','Sta. Rita Hills','California','Turner Vineyard',2009,48,91,150,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (148,'Pinot Noir','Loring','Sta. Rita Hills','California','Rancho La Vina Vineyard',2009,45,91,125,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (149,'Pinot Noir','Athair','Russian River Valley','California','Pinot Noir',2008,36,90,919,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (150,'Pinot Noir','Clouds Rest','Sonoma Coast','California','Limited Release',2007,69,90,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (151,'Pinot Noir','Loring','San Luis Obispo County','California','Aubaine Vineyard',2009,45,90,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (152,'Pinot Noir','Loring','Sta. Rita Hills','California','Pinot Noir',2009,29,88,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (153,'Pinot Noir','Siduri','Sonoma County','California','Pinot Noir',2009,20,88,2657,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (154,'Pinot Noir','Castle Rock','Carneros','California','Pinot Noir',2008,14,84,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (155,'Syrah','Sine Qua Non','Sta. Rita Hills','California','A Shot in the Dark Eleven Confessions Vineyard',2006,200,98,442,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (156,'Syrah','Favia','Amador County','California','Quarzo',2008,65,95,154,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (157,'Syrah','Roar','Santa Lucia Highlands','California','Rosella''s Vineyard',2008,40,94,140,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (158,'Syrah','Carlisle','Bennett Valley','California','Cardiac Hill',2008,45,93,239,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (159,'Syrah','Herman Story','Santa Barbara County','California','Larner Vinyard',2008,36,93,135,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (160,'Syrah','Herman Story','Santa Barbara County','California','White Hawk Vineyard',2008,36,93,132,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (161,'Syrah','Zaca Mesa','Santa Ynez Valley','California','Mesa Reserve',2007,42,93,992,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (162,'Syrah','JC Cellars','California','California','Twist of Fate',2008,55,92,206,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (163,'Syrah','Ramey','Sonoma Coast','California','Syrah',2008,38,92,1750,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (164,'Syrah','Roar','Santa Lucia Highlands','California','Garys'' Vineyard',2008,40,92,110,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (165,'Syrah','Adobe Road','Dry Creek Valley','California','Kemp Vineyard',2007,40,91,235,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (166,'Syrah','Novy','Russian River Valley','California','Christensen Family Vineyard',2008,27,91,177,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (167,'Syrah','Ojai','Sta. Rita Hills','California','Melville Vineyards',2006,44,91,238,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (168,'Syrah','Joseph Phelps','Napa Valley','California','Syrah',2008,50,90,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (169,'Syrah','Red Car','California','California','The Flight',2008,55,90,394,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (170,'Syrah','Tensley','Santa Barbara County','California','Colson Canyon Vineyard',2009,38,90,1495,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (171,'Syrah','Red Lava','Red Hills Lake County','California','Syrah',2007,22,89,977,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (172,'Syrah','Rosenblum','Solano County','California','England-Shaw',2007,35,89,735,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (173,'Syrah','Eberle','Paso Robles','California','Rose Steinbeck Vineyard',2009,17,88,705,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (174,'Syrah','Keller','Sonoma Coast','California','La Cruz Vineyard',2007,40,88,308,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (175,'Syrah','Fess Parker','Santa Barbara County','California','Syrah',2008,20,88,2831,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (176,'Syrah','Pride','Sonoma County','California','Syrah',2008,60,88,575,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (177,'Syrah','Red Car','Sonoma County','California','Syrah',2008,45,88,961,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (178,'Syrah','Rosenblum','Lake County','California','Snows Lake Vineyard',2007,25,88,486,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (179,'Syrah','Rosenblum','Lodi','California','Abba Vineyard',2007,25,88,450,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (180,'Syrah','Stolpman','Santa Ynez Valley','California','Originals',2008,38,88,950,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (181,'Syrah','Boheme','Sonoma Coast','California','Que Syrah Vineyard',2006,40,87,185,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (182,'Syrah','J. Lohr','Paso Robles','California','Gesture Limited Release',2008,30,87,514,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (183,'Syrah','Montes','Paso Robles','California','Star Angel ',2007,35,87,3000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (184,'Syrah','Rosenblum','Sonoma County','California','Kick Ranch Reserve',2007,45,87,496,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (185,'Syrah','Stolpman','Santa Ynez Valley','California','Syrah',2008,30,87,1500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (186,'Syrah','Zaca Mesa','Santa Ynez Valley','California','Syrah',2007,24,87,7651,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (187,'Syrah','Domaine de la Terre Rouge','California','California','Les Cotes De L''Ouest',2008,18,84,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (188,'Syrah','Fetzer','California','California','Shiraz',2008,9,83,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (189,'Zinfandel','Carlisle','Russian River Valley','California','Carlisle Vineyard',2008,43,93,325,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (190,'Zinfandel','Turley','Howell Mountain','California','Cedarman',2008,29,93,400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (191,'Zinfandel','Turley','Napa Valley','California','Tofanelli Vineyard',2008,34,93,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (192,'Zinfandel','Collier Falls','Dry Creek Valley','California','Private Reserve',2006,32,92,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (193,'Zinfandel','Turley','Sonoma Valley','California','Fredericks Vineyard',2008,42,91,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (194,'Zinfandel','Carlisle','Sonoma Valley','California','Rossi Ranch',2008,40,90,119,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (195,'Zinfandel','Dark Horse','Dry Creek Valley','California','Treborce Vineyard',2008,28,90,750,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (196,'Zinfandel','St. Francis','Sonoma County','California','Wild Oak Old Vines',2007,38,89,1900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (197,'Zinfandel','Girard','Napa Valley','California','Old Vine',2008,24,88,2850,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (198,'Zinfandel','Sextant','Paso Robles','California','Wheelhouse',2008,20,88,3300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (199,'Zinfandel','Terra d''Oro','Amador County','California','Zinfandel',2007,18,88,14000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (200,'Zinfandel','Artezin','Mendocino County','California','Zinfandel',2009,18,87,15000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (201,'Zinfandel','Terra d''Oro','Amador County','California','SHR Field Blend',2007,30,87,1250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (202,'Zinfandel','Cameron Hughes','Lake County','California','Lot 154',2006,13,86,584,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (203,'Zinfandel','Rubicon Estate','Rutherford','California','Edizione Pennino',2008,45,86,2278,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (204,'Chardonnay','Lewis','Napa Valley','California','Chardonnay',2009,48,92,1800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (205,'Chardonnay','Keller','Sonoma Coast','California','La Cruz Vineyard',2008,36,91,507,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (206,'Merlot','Darioush','Napa Valley','California','Signature',2007,48,89,1779,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (207,'Tempranillo','Four Vines','Paso Robles','California','Loco',2008,40,88,700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (208,'Chardonnay','CC:','California','California','Chardonnay',2009,15,86,5000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (209,'Syrah','Four Vines','Amador County','California','Bailey Vineyard',2005,38,93,440,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (210,'Syrah','Red Car','California','California','Twenty Two',2005,60,93,111,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (211,'Syrah','Herman Story','Santa Ynez Valley','California','Larner Vinyard',2005,28,92,432,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (212,'Syrah','Krupp Brothers','Napa Valley','California','Black Bart Stagecoach Vineyard',2005,52,91,1219,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (213,'Syrah','Paloma','Dry Creek Valley','California','Polomita Hamilton Vineyard',2005,45,91,250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (214,'Syrah','Rosenblum','Yolo County','California','Rominger Vineyard',2005,25,91,1125,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (215,'Zinfandel','Four Vines','Amador County','California','Maverick',2005,24,91,2529,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (216,'Syrah','Chateau Potelle','Mount Vedeer','California','VGS',2004,75,90,238,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (217,'Syrah','Kosta Browne','Russian River Valley','California','Amber Ridge Vineyard',2004,45,90,320,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (218,'Syrah','Ojai','California','California','Roll Ranch Vineyard',2004,45,90,700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (219,'Syrah','Whitestone','Sonoma Coast','California','Guidici Famili Vineyard',2005,55,90,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (220,'Pinot Noir','Adrian Fog','Anderson Valley','California','Savoy Vineyard',2005,75,92,440,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (221,'Pinot Noir','Davis Bynum','Russian River Valley','California','The Backbone',2004,75,92,117,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (222,'Pinot Noir','Davis Bynum','Russian River Valley','California','Laurels Estate Vineyard',2004,75,91,142,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (223,'Pinot Noir','Davis Bynum','Russian River Valley','California','Bynum & Moshin Vineyards',2004,50,91,314,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (224,'Pinot Noir','Calera','Mount Harlan','California','Jensen Vineyard',2004,60,91,1262,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (225,'Zinfandel','Rosenblum','Rockpile','California','Rockpile Road Vineyard',2005,35,91,3558,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (226,'Pinot Noir','Toulouse','Anderson Valley','California','Pinot Noir',2005,39,91,1050,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (227,'Pinot Noir','Calera','Mount Harlan','California','Thirtieth Anniverasry Vintage Mt. Harlan Cuvee',2005,30,90,403,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (228,'Chardonnay','DuMOL','Sonoma County','California','Green River Isobel',2005,60,95,558,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (229,'Chardonnay','Barnett','Carneros','California','Sengiacomo Vineyard',2005,29,93,1138,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (230,'Chardonnay','Chasseur','Russian River Valley','California','Lorenzo',2005,55,93,371,2008
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (231,'Chardonnay','DuMOL','Russian River Valley','California','Chloe',2005,60,92,708,2008
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (232,'Chardonnay','Chalk Hill','Chalk Hill','California','Chardonnay',2005,45,90,15000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (233,'Viognier','Darioush','Napa Valley','California','Signature',2006,35,90,1376,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (234,'Marsanne','Krupp Brothers','Napa Valley','California','Stagecoach Vineyard Black Bart',2005,37,90,620,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (235,'Sauvignon Blanc','Sbragia Family','Dry Creek Valley','California','Home Ranch',2006,20,90,620,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (236,'Cabernet Sauvingnon','Hourglass','Napa Valley','California','Cabernet Sauvignon',2006,135,97,700,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (237,'Cabernet Sauvingnon','Dancing Hares','Napa Valley','California','Cabernet Sauvignon',2005,95,95,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (238,'Cabernet Sauvingnon','Lewis','Napa Valley','California','Reserve',2006,125,95,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (239,'Cabernet Sauvingnon','Bucella','Napa Valley','California','Cabernet Sauvignon',2006,135,93,792,2010
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (240,'Cabernet Sauvingnon','Casa Piena','Napa Valley','California','Cabernet Sauvignon',2006,125,93,240,2010
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (241,'Cabernet Sauvingnon','The Four','Napa Valley','California','Cabernet Sauvignon',2006,75,93,310,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (242,'Cabernet Sauvingnon','Veraison','Napa Valley','California','Stagecoach Vineyard',2005,60,93,1232,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (243,'Cabernet Sauvingnon','Barrack','Santa Ynez Valley','California','Ten-Goal Happy Canyon Vineyards',2005,60,92,350,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (244,'Cabernet Sauvingnon','Snowden','Napa Valley','California','The Ranch',2006,40,92,1200,2010
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (245,'Cabernet Sauvingnon','Cade','Napa Valley','California','Napa Cuvee',2006,60,91,2200,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (246,'Cabernet Sauvingnon','Louis M. Martini','Sonoma Valley','California','Monte Rosso Vineyard',2005,85,91,2550,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (247,'Cabernet Sauvingnon','PerryMoore','Oakville','California','Beckstoffer To Kalon Vineyard',2005,100,91,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (248,'Cabernet Sauvingnon','Frank Family','Rutherford','California','Reserve',2005,85,90,2400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (249,'Cabernet Sauvingnon','Highlands','Napa Valley','California','Cabernet Sauvignon',2006,55,90,1000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (250,'Cabernet Sauvingnon','Ilsley','Stags Leap District','California','Cabernet Sauvignon',2005,55,90,318,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (251,'Cabernet Sauvingnon','PerryMoore','St. Helena','California','Dr. Crane Vineyard',2005,100,90,250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (252,'Chardonnay','Kazme & Blaise','Carneros','California','Boonfly''s Hill',2006,50,95,90,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (253,'Chardonnay','Kistler','Sonoma County','California','McCrea Vineyard',2006,75,95,3634,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (254,'Chardonnay','Peter Michael','Sonoma County','California','Ma Belle-Fille',2007,85,95,2780,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (255,'Chardonnay','Three Sticks','Sonoma Valley','California','Durell Vineyard',2006,45,95,220,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (256,'Chardonnay','Tor','Sonoma Valley','California','Durell Vineyard Wente Clone',2007,60,95,80,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (257,'Chardonnay','Failla','Sonoma Coast','California','Estate Vineyard',2007,42,94,125,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (258,'Chardonnay','Kistler','Russian River Valley','California','Wine Hill Vineyard',2006,75,94,3640,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (259,'Chardonnay','Peter Michael','Sonoma County','California','Belle Cote',2007,75,94,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (260,'Chardonnay','Peter Michael','Sonoma County','California','Mon Plaisir',2007,80,94,1050,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (261,'Chardonnay','Peirson Meyer','Sonoma County','California','Untilited #3',2007,75,94,125,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (262,'Chardonnay','Rodney Strong','Russian River Valley','California','Reserve',2006,40,94,2448,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (263,'Chardonnay','Au Bon Climat','Santa Barbara County','California','Los Alamos Vineyard Historic Vineyards Collection',2007,25,93,325,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (264,'Chardonnay','HdV','Carneros','California','Hyde Vineyards',2006,60,93,1562,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (265,'Chardonnay','Kistler','Carneros','California','Hudson Vineyard',2006,75,93,1818,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (266,'Chardonnay','Landmark','Sonoma County','California','Damaris Reserve ',2006,40,93,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (267,'Chardonnay','Pahlmeyer','Sonoma Coast','California','Chardonnay',2007,70,93,1620,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (268,'Chardonnay','Peirson Meyer','Sonoma Coast','California','Cahrles Heintz Vineyard',2007,55,93,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (269,'Chardonnay','Ridge','Santa Cruz Mountains','California','Santa Cruz Mountains Estate',2007,40,93,400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (270,'Chardonnay','Shafer','California','California','Red Shoulder Ranch',2007,48,93,5500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (271,'Chardonnay','Souverain','Russian River Valley','California','Winmaker''s Reserve',2007,30,93,313,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (272,'Chardonnay','Acacia','Carneros','California','Sangiacomo Vineyard',2007,40,92,484,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (273,'Chardonnay','Beringer','Napa Valley','California','Sbraglia Limited-Release',2007,40,92,5600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (274,'Chardonnay','Chalone','Chalone','California','Chardonnay',2007,25,92,16801,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (275,'Chardonnay','Chateau St. Jean','Sonoma County','California','Reserve',2006,45,92,4600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (276,'Chardonnay','El Molino','Rutherford','California','Chardonnay',2007,45,92,878,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (277,'Chardonnay','Freeman','Russian River Valley','California','Ryo-fu',2006,44,92,418,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (278,'Chardonnay','Hanzell','Sonoma Valley','California','Chardonnay',2006,70,92,3253,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (279,'Chardonnay','Hudson Vineyards','Napa Valley','California','Carneros',2006,60,92,350,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (280,'Chardonnay','Kistler','Russian River Valley','California','Dutton Ranch',2006,75,92,1810,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (281,'Chardonnay','Luna','Napa Valley','California','Chardonnay',2006,40,92,204,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (282,'Chardonnay','Maldonado','Napa Valley','California','Los Olivos Vineyard',2006,49,92,566,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (283,'Chardonnay','Peter Michael','Sonoma County','California','La Carrlere',2007,80,92,2549,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (284,'Chardonnay','Pahlmeyer','Napa Valley','California','Chardonnay',2007,70,92,3341,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (285,'Chardonnay','Sbragia Family','Dry Creek Valley','California','Home Ranch',2007,26,92,2657,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (286,'Chardonnay','D.R. Stephens','Napa Valley','California','Chardonnay',2007,50,92,455,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (287,'Chardonnay','Truchard','Napa Valley','California','Carneros',2007,30,92,2930,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (288,'Chardonnay','Vineyard 7&8','Spring Mountain District','California','Chardonnay',2007,60,92,275,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (289,'Chardonnay','Anaba','Sonoma Coast','California','Chardonnay',2007,32,91,938,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (290,'Chardonnay','Armida','Russian River Valley','California','Keefer Ranch',2007,28,91,232,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (291,'Chardonnay','Au Bon Climat','Santa Barbara County','California','Chardonnay',2007,20,91,12000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (292,'Chardonnay','Beringer','Napa Valley','California','Private Reserve',2007,35,91,21900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (293,'Chardonnay','Cakebread','Napa Valley','California','Carneros Reserve',2006,55,91,1000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (294,'Chardonnay','Calera','Mount Harlan','California','Chardonnay',2007,25,91,663,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (295,'Chardonnay','Celani Family','Napa Valley','California','Chardonnay',2007,40,91,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (296,'Chardonnay','Domain Chandon','Carneros','California','Chardonnay',2006,26,91,4600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (297,'Chardonnay','Dutton-Goldfield','Russian River Valley','California','Dutton Ranch',2007,35,91,3981,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (298,'Chardonnay','Far Niente','Napa Valley','California','Chardonnay',2007,56,91,30000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (299,'Chardonnay','Ferrari-Carano','Russian River Valley','California','Emelia''s Cuvee',2007,36,91,465,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (300,'Chardonnay','Fog Dog','Sonoma Coast','California','Chardonnay',2006,40,91,1300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (301,'Chardonnay','Freestone','Sonoma Coast','California','Ovation',2006,60,91,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (302,'Chardonnay','L''Angevin','Russian River Valley','California','Laughlin Family Vineyard',2007,44,91,350,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (303,'Chardonnay','Marimar Estate','Russian River Valley','California','Don Miguel Vineyard Lia Torres Family Vineyards',2006,49,91,355,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (304,'Chardonnay','Merryvale','Carneros','California','Chardonnay',2007,35,91,2215,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (305,'Chardonnay','Neyers','Sonoma Coast','California','B. Theriot Vineyard',2007,48,91,202,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (306,'Chardonnay','Olabisi','Carneros','California','Ceja Vineyard',2007,40,91,285,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (307,'Chardonnay','Rombauer','Carneros','California','Chardonnay',2007,32,91,40000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (308,'Chardonnay','Talley','Edna Valley','California','Chardonnay',2007,26,91,445,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (309,'Chardonnay','Talley','Arroyo Grande Valley','California','Chardonnay',2007,26,91,4603,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (310,'Chardonnay','Vine Cliff','Carneros','California','Proprietary Reserve',2007,60,91,545,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (311,'Chardonnay','Vine Cliff','Carneros','California','Los Carneros',2007,39,91,1798,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (312,'Chardonnay','Artesa','Carneros','California','Chardonnay',2007,20,90,33000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (313,'Chardonnay','Beaulieu Vineyard','Napa Valley','California','Carneros',2007,17,90,15000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (314,'Chardonnay','Byron','Santa Maria Valley','California','Chardonnay',2007,26,90,4406,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (315,'Chardonnay','Darioush','Napa Valley','California','Signature',2007,43,90,1761,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (316,'Chardonnay','Ferrari-Carano','Russian River Valley','California','Valley Dominique',2007,38,90,276,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (317,'Chardonnay','The Hess Collection','Mount Vedeer','California','Chardonnay',2007,35,90,1900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (318,'Chardonnay','Jocelyn Lonen','Carneros','California','Founder''s',2007,45,90,200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (319,'Chardonnay','Kistler','Sonoma Valley','California','Kistler Vineyard',2006,80,90,1815,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (320,'Chardonnay','Laird Family','Carneros','California','Gold Creek Ranch',2007,30,90,1500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (321,'Chardonnay','Mer Soleil','Santa Lucia Highlands','California','Chardonnay',2006,42,90,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (322,'Chardonnay','Nicholson Ranch','Sonoma Valley','California','Cuvee Natalie',2006,48,90,325,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (323,'Chardonnay','Orogeny','Green Valley of Russian River Valley','California','Chardonnay',2007,25,90,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (324,'Chardonnay','Ramey','Sonoma Coast','California','Chardonnay',2007,38,90,2100,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (325,'Chardonnay','Robert Young','Alexander Valley','California','Chardonnay',2006,40,90,1990,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (326,'Chardonnay','HdV','Carneros','California','De La Guerra',2007,40,90,506,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (327,'Chardonnay','Maldonado','Sonoma County','California','Parr Vineyard',2006,24,90,900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (328,'Chardonnay','Cakebread','Napa Valley','California','Chardonnay',2007,39,90,25000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (329,'Chardonnay','Cuvasion','Napa Valley','California','Carneros',2007,24,88,40000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (330,'Chardonnay','Kunde Estate','Sonoma Valley','California','Reserve',2006,30,88,5800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (331,'Chardonnay','Ramey','Carneros','California','Chardonnay',2007,38,88,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (332,'Chardonnay','Saddleback','Napa Valley','California','Chardonnay',2007,26,88,831,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (333,'Chardonnay','Sebastiani','Sonoma County','California','Chardonnay',2007,13,88,82130,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (334,'Chardonnay','White Rock','Napa Valley','California','Chardonnay',2007,30,88,800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (335,'Chardonnay','Acacia','Carneros','California','Chardonnay',2007,22,87,70200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (336,'Chardonnay','Kunde Estate','Sonoma Valley','California','Chardonnay',2007,17,87,35000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (337,'Chardonnay','Moon Mountain','Sonoma County','California','Chardonnay',2007,13,87,42250,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (338,'Chardonnay','Waterstone','Carneros','California','Chardonnay',2007,18,87,1832,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (339,'Chardonnay','Napa Family','Napa Valley','California','Finest Selection Reserve',2007,10,86,2853,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (340,'Pinot Noir','Roessler','Anderson Valley','California','Valley Savoy',2007,46,94,268,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (341,'Pinot Noir','Vision Cellars','Russian River Valley','California','Coster Vineyard',2007,42,93,286,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (342,'Pinot Noir','Ampelos','Sta. Rita Hills','California','Lambda',2007,35,92,1094,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (343,'Pinot Noir','Freeman','Sonoma Coast','California','Pinot Noir',2007,44,92,1068,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (344,'Pinot Noir','Baker Lane','Sonoma Coast','California','Hurst Vineyard',2007,36,91,360,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (345,'Pinot Noir','Failla','Russian River Valley','California','Keefer Ranch',2007,45,91,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (346,'Pinot Noir','Failla','Sonoma Coast','California','Pinot Noir',2007,34,91,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (347,'Pinot Noir','Kutch','Sonoma Coast','California','McDougal Ranch',2007,48,91,125,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (348,'Pinot Noir','Siduri','Sta. Rita Hills','California','Clos Pepe Vineyard',2007,54,91,241,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (349,'Pinot Noir','Small Vines','Russian River Valley','California','Pinot Noir',2006,50,91,365,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (350,'Pinot Noir','Vision Cellars','Sonoma County','California','Pinot Noir',2007,38,90,900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (351,'Pinot Noir','Freeman','Russian River Valley','California','Pinot Noir',2006,44,89,1592,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (352,'Pinot Noir','Kutch','Sonoma Coast','California','Kanzler Vineyard',2007,48,89,175,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (353,'Pinot Noir','MacRostie','Sonoma Coast','California','Wildcat Mountain Vineyard',2006,45,89,1003,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (354,'Pinot Noir','Baker Lane','Sonoma Coast','California','Ramondo Vineyard',2007,42,88,777,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (355,'Pinot Noir','Fort Ross','Sonoma Coast','California','Symposium Fort Ross Vineyard',2066,32,88,2584,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (356,'Pinot Noir','Landmark','Sonoma Coast','California','Grand Detour',2007,40,88,2500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (357,'Pinot Noir','Sequana','Green Valley of Russian River Valley','California','Valley Dutton Ranch',2007,40,88,728,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (358,'Pinot Noir','Bernardus','Monterey County','California','Pinot Noir',2007,25,87,4715,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (359,'Pinot Noir','Marting Ray','Santa Barbara County','California','Pinot Noir',2007,25,87,5800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (360,'Syrah','Carlisle','Russian River Valley','California','Papa''s Block',2007,43,98,307,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (361,'Syrah','Carlisle','Santa Lucia Highlands','California','Rosella''s Vineyard',2007,43,94,192,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (362,'Syrah','Jemrose','Bennett Valley','California','Gloria''s Gem',2006,75,94,48,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (363,'Syrah','Duchamp','Dry Creek Valley','California','Cuvee Trouvee',2006,38,93,300,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (364,'Syrah','Duchamp','Dry Creek Valley','California','Grand Master',2006,55,93,175,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (365,'Syrah','Martinelli','Russian River Valley','California','Zio Tony Ranch Gianna Marie',2006,75,93,305,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (366,'Syrah','McPrice Myers','Arroyo Grande Valley','California','Les Galets',2006,36,93,198,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (367,'Syrah','Ampelos','Sta. Rita Hills','California','Gamma',2005,35,92,264,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (368,'Syrah','Stephen Test','Dry Creek Valley','California','Unti Vineyard',2006,30,91,128,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (369,'Zinfandel','Carlisle','Dry Creek Valley','California','Zinfandel',2007,33,95,360,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (370,'Zinfandel','Linne Calodo','Paso Robles','California','Problem Child',2007,48,94,580,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (371,'Zinfandel','Carlisle','Sonoma Valley','California','Rossi Ranch',2007,40,93,236,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (372,'Zinfandel','Carlisle','Sonoma County','California','Zinfandel',2007,23,92,539,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (373,'Zinfandel','Carlisle','Russian River Valley','California','Montafi Ranch',2007,43,91,258,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (374,'Zinfandel','Dancing Lady','Alexander Valley','California','Old vine Della Costa Family Vineyard',2007,27,91,321,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (375,'Zinfandel','Martinelli','Russian River Valley','California','Giuseppe & Luisa',2007,50,91,825,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (376,'Zinfandel','D-Cubed Cellars','Napa Valley','California','Zinfandel',2006,27,89,1100,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (377,'Zinfandel','De Loach','Russian River Valley','California','Zinfandel',2007,20,89,1830,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (378,'Zinfandel','Saucelito Canyon','San Luis Obispo County','California','Backroads',2007,18,89,563,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (379,'Zinfandel','Rosenblum','Paso Robles','California','Appelation Series',2006,18,88,8913,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (380,'Zinfandel','Sausal','Alexander Valley','California','50  Year Old Vines',2006,19,88,8913,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (381,'Zinfandel','Dry Creek','Sonoma County','California','Heritage',2007,18,87,13877,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (382,'Zinfandel','Klinker Brick','Lodi','California','Old Vine',2006,18,87,20000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (383,'Zinfandel','Schrader','Napa Valley','California','Vieux-Os Hell Hole Cuvee Old Vine',2006,35,87,375,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (384,'Zinfandel','Rosenblum','Contra Costa County','California','Planchon Vineyard',2006,26,86,2425,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (385,'Zinfandel','Rodney Strong','Sonoma County','California','Knotty Vines',2007,20,86,18655,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (386,'Zinfandel','Cardinal Zin','Calaveras County','California','Beastly Old Vines',2006,20,84,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (387,'Zinfandel','Cline','California','California','Ancient Vines',2007,15,84,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (388,'Zinfandel','Peachy Canyon','Paso Robles','California','Incredible Red',2007,12,82,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (389,'Zinfandel','Renwood','Sierra Foothills','California','Zinfandel',2006,10,82,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (390,'Zinfandel','Renwood','Fiddletown','California','Zinfandel',2006,25,78,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (391,'Cabernet Franc','Pride','Sonoma County','California','Cabernet Franc',2006,60,92,1128,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (392,'Zinfandel','D-Cubed Cellars','Napa Valley','California','Primitivo',2006,25,88,226,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (393,'Merlot','Thomas Henry','Napa Valley','California','Merlot',2005,12,84,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (394,'Cabernet Sauvingnon','Caymus','Napa Valley','California','Special Selection',2008,130,94,15618,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (395,'Cabernet Sauvingnon','Phifer Pavitt','Napa Valley','California','Date Night',2007,75,94,400,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (396,'Cabernet Sauvingnon','Turnbull','Napa Valley','California','Black Label',2007,100,94,500,2013
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (397,'Cabernet Sauvingnon','Cavus','Stags Leap District','California','Cabernet Sauvignon',2007,90,93,155,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (398,'Cabernet Sauvingnon','Girard','Napa Valley','California','Artistry',2008,40,88,4944,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (399,'Cabernet Sauvingnon','Montes','Napa Valley','California','Napa Angel Aurelio''s Selection',2007,90,87,3000,2013
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (400,'Chardonnay','Maybach','Sonoma Coast','California','Eterium B. Thieriot Vineyard',2009,78,95,60,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (401,'Chardonnay','Freestone','Sonoma Coast','California','Chardonnay',2008,55,93,800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (402,'Chardonnay','Morgan','Monterey County','California','Metallico Un-Oaked',2009,20,91,3800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (403,'Chardonnay','Sterling','Napa Valley','California','Reserve',2008,35,91,1450,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (404,'Chardonnay','Gary Farrell','Russian River Valley','California','Russian River Selection',2008,32,89,4474,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (405,'Chardonnay','Y3','Napa Valley','California','Chardonnay',2009,20,89,2820,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (406,'Chardonnay','Bogle','California','California','Chardonnay',2009,10,88,250000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (407,'Pinot Noir','Adrian Fog','Sonoma Coast','California','Numbers',2008,75,93,340,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (408,'Pinot Noir','Fog Dog','Sonoma Coast','California','Pinot Noir',2008,35,89,8000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (409,'Merlot','Rutherford Hill','Napa Valley','California','Merlot',2006,25,89,42546,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (410,'Zinfandel','Kokomo','Sonoma County','California','Zinfandel',2008,22,88,800,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (411,'Merlot','Black Box','California','California','Merlot',2008,25,83,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (412,'Zinfandel','Joel Gott','California','California','Zinfandel',2008,17,83,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (413,'Cabernet Sauvingnon','Paul Hobbs','St. Helena','California','Beckstoffer Dr. Crane Vineyard',2007,150,97,586,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (414,'Cabernet Sauvingnon','Pina','Napa Valley','California','D''Adamo Vineyard',2007,75,93,1085,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (415,'Cabernet Sauvingnon','Boyanci','Napa Valley','California','InSpire',2007,60,92,715,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (416,'Cabernet Sauvingnon','Guarachi','Napa Valley','California','Cabernet Sauvignon',2007,65,92,1269,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (417,'Cabernet Sauvingnon','Paul Hobbs','Napa Valley','California','Cabernet Sauvignon',2007,75,92,5653,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (418,'Cabernet Sauvingnon','Keever','Yountville','California','Cabernet Sauvignon',2007,90,92,650,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (419,'Cabernet Sauvingnon','Dos Lagos','Atlas Peak','California','Cabernet Sauvignon',2007,125,88,120,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (420,'Cabernet Sauvingnon','Erna Schein','Napa Valley','California','Spare Me',2007,45,88,280,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (421,'Cabernet Sauvingnon','Erna Schein','California','California','Jersey Boy',2007,50,88,384,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (422,'Cabernet Sauvingnon','Fleming Jenkins','Napa Valley','California','Choreography',2006,50,88,643,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (423,'Cabernet Sauvingnon','Girard','Napa Valley','California','Artistry',2007,40,88,4600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (424,'Cabernet Sauvingnon','Langtry','Lake County','California','Tephra Ridge Vineyard',2006,40,88,342,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (425,'Cabernet Sauvingnon','Maldonado','Spring Mountain District','California','Peter Newton Vineyard',2006,92,88,126,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (426,'Cabernet Sauvingnon','Nickel & Nickel','Yountville','California','State Lane Ranch',2006,90,88,430,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (427,'Cabernet Sauvingnon','Prime','Napa Valley','California','District 4',2007,39,88,304,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (428,'Cabernet Sauvingnon','David Arthur','Napa Valley','California','Elevation 1147',2007,135,87,541,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (429,'Cabernet Sauvingnon','Duckhorn','Napa Valley','California','Cabernet Sauvignon',2006,65,87,13744,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (430,'Cabernet Sauvingnon','Krutz Family','Napa Valley','California','Stagecoach Vineyard',2006,70,87,315,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (431,'Cabernet Sauvingnon','Sebastiani','Sonoma County','California','Cabernet Sauvignon',2006,18,87,120123,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (432,'Cabernet Sauvingnon','Artesa','Napa-Sonoma counties','California','Elements',2006,18,86,8000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (433,'Cabernet Sauvingnon','Blue Rock','Alexander Valley','California','Cabernet Sauvignon',2006,47,86,784,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (434,'Cabernet Sauvingnon','Daou','Paso Robles','California','La Capilla Collection',2007,46,86,873,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (435,'Cabernet Sauvingnon','Merryvale','Napa Valley','California','Cabernet Sauvignon',2006,55,86,2284,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (436,'Cabernet Sauvingnon','Cycles Gladiator','California','California','Cabernet Sauvignon',2007,10,80,NULL,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (437,'Grenache','Sine Qua Non','California','California','To the Rescue',2007,100,93,164,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (438,'Grenache','Sine Qua Non','California','California','Pictures',2007,135,91,764,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (439,'Grenache','Quivara','Dry Creek Valley','California','Rose Wine Creek Ranch',2009,15,90,448,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (440,'Merlot','Keenan','Spring Mountain District','California','Mailbox Vineyard Drive',2006,60,88,330,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (441,'Merlot','Langtry','Lake County','California','Tephra Ridge Vineyard',2006,40,88,205,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (442,'Merlot','White Oak','Napa Valley','California','Merlot',2007,26,88,1987,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (443,'Merlot','Goldschmidt','Alexander Valley','California','Chelsea Goldschmidt',2008,15,87,3500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (444,'Merlot','Merryvale','Napa Valley','California','Merlot',2006,39,86,1587,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (445,'Pinot Noir','DuMOL','Russian River Valley','California','Ryan',2007,76,94,850,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (446,'Pinot Noir','Paul Hobbs','Russian River Valley','California','Pinot Noir',2008,45,94,3644,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (447,'Pinot Noir','DuMOL','Russian River Valley','California','Finn',2007,80,93,363,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (448,'Pinot Noir','DuMOL','Red Hills Lake County','California','Aidan',2007,76,92,380,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (449,'Pinot Noir','DuMOL','Sonoma Coast','California','Eoin',2007,76,92,375,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (450,'Pinot Noir','Paul Hobbs','Russian River Valley','California','Ulises Valdez Vineyard',2008,70,92,282,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (451,'Pinot Noir','Mueller','Russian River Valley','California','Pinot Noir',2007,25,92,442,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (452,'Pinot Noir','Fleming Jenkins','California','California','Victories Rose',2009,20,89,480,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (453,'Pinot Noir','Keller','Sonoma Coast','California','La Cruz Vineyard',2007,44,88,510,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (454,'Pinot Noir','Baileyana','Edna Valley','California','Grand Firepeak Cuvee Firepeak Vineyard',2007,33,87,6334,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (455,'Pinot Noir','Testarossa','Santa Lucia Highlands','California','Sleepy Hollow Vineyard',2008,59,87,600,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (456,'Pinot Noir','Demetria','Sta. Rita Hills','California','Pinot Noir',2007,40,86,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (457,'Sauvignon Blanc','Merry Edwards','Russian River Valley','California','Sauvignon Blanc',2008,30,93,3880,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (458,'Sauvignon Blanc','Robert Mondavi','Napa Valley','California','Fume Blanc',2008,20,88,50543,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (459,'Sauvignon Blanc','Illumination','Napa Valley','California','Sauvignon Blanc',2008,40,87,3150,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (460,'Sauvignon Blanc','Langtry','Guenoc Valley','California','Lillie Vineyard',2008,20,87,659,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (461,'Sauvignon Blanc','David Arthur','Napa Valley','California','Sauvignon Blanc',2008,25,86,566,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (462,'Syrah','Carlisle','Russian River Valley','California','Papa''s Block',2008,45,92,212,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (463,'Syrah','Sine Qua Non','California','California','Labels',2007,135,92,1421,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (464,'Syrah','Fleming Jenkins','Livermore Valley','California','Madden Ranch',2007,40,89,456,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (465,'Syrah','Ampelos','Santa Barbara County','California','Rose',2009,18,88,320,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (466,'Syrah','Carlisle','Santa Lucia Highlands','California','Rosella''s Vineyard',2008,45,88,171,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (467,'Syrah','Ancient Peaks','Paso Robles','California','Syrah',2007,16,87,869,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (468,'Zinfandel','Bradford Mountain','Dry Creek Valley','California','Grist Vineyard',2006,33,90,500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (469,'Zinfandel','Hartford Family','Russian River Valley','California','Highwire Vineyard',2008,55,89,340,2012
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (470,'Zinfandel','Haywood','Sonoma Valley','California','Rocky Terrace Los Chamizal Vineyards',2007,35,89,590,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (471,'Zinfandel','Kunde Estate','Sonoma Valley','California','Century Vines Reserve',2007,35,89,2000,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (472,'Zinfandel','Saxon Brown','Sonoma Valley','California','Casa Santinamaria Vineyards',2006,38,89,327,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (473,'Zinfandel','Valdez','Rockpile','California','Boticelli Vineyards',2007,41,89,233,2011
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (474,'Zinfandel','Dashe','Alexander Valley','California','Todd Brothers Ranch Old Vines',2007,32,88,476,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (475,'Zinfandel','Del Carlo','Dry Creek Valley','California','Old Vine Teldeschi Vineyard Home Ranch',2006,32,88,294,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (476,'Zinfandel','Dry Creek','Dry Creek Valley','California','Old Vine',2007,28,88,5555,2015
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (477,'Zinfandel','Dry Creek','Dry Creek Valley','California','Somers Ranch',2007,34,88,469,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (478,'Zinfandel','Frank Family','Napa Valley','California','Reserve',2007,50,88,748,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (479,'Zinfandel','Haywood','Sonoma Valley','California','Morning Sun Los Chamizal Vineyards',2007,35,88,399,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (480,'Zinfandel','Rock Wall','Contra Costa County','California','Jesse''s Vineyard',2008,28,88,765,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (481,'Zinfandel','Rosenblum','Contra Costa County','California','Carla''s Reserve',2007,30,88,1909,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (482,'Zinfandel','Sbragia Family','Dry Creek Valley','California','Gino''s Vineyard',2007,28,88,544,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (483,'Zinfandel','Artezin','Amador-Mendocino-Sonoma Counties','California','Zinfandel',2008,18,87,5856,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (484,'Zinfandel','Bradford Mountain','Dry Creek Valley','California','Zinfandel',2006,22,87,1900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (485,'Zinfandel','Cline','Contra Costa County','California','Bridgehead',2008,25,87,850,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (486,'Zinfandel','Dancing Lady','Alexander Valley','California','Old vine Della Costa Family Vineyard',2008,24,87,358,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (487,'Zinfandel','Mauritson','Dry Creek Valley','California','Zinfandel',2008,27,87,1457,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (488,'Zinfandel','Neyers','Contra Costa County','California','Pato Vineyard',2008,30,87,1200,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (489,'Zinfandel','Rosenblum','Sonoma County','California','Zinfandel',2007,18,87,5297,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (490,'Zinfandel','Rosenblum','Sonoma Valley','California','Cullinane Reserve',2007,45,87,238,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (491,'Zinfandel','Rubicon Estate','Rutherford','California','Edizione Pennino',2007,45,87,2499,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (492,'Zinfandel','Sebastiani','Dry Creek Valley','California','Zinfandel',2008,24,87,1284,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (493,'Zinfandel','Pedroncelli','Dry Creek Valley','California','Bushnell Vineyard',2007,18,86,3500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (494,'Zinfandel','Sobon Estate','Amador County','California','Old Vines',2008,14,86,6900,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (495,'Zinfandel','Cline','California','California','Zinfandel',2008,12,85,97500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (496,'Roussanne','Sine Qua Non','California','California','To the Rescue',2006,100,91,139,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (497,'Sangiovese','Altamura','Napa Valley','California','Sangiovese',2006,48,88,1500,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (498,'Barbera','Enotria','Mendocino County','California','Barbera',2006,17,87,1100,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (499,'Zinfandel','C.G. Di Arle','Shenandoah Valley','California','Primitivo Block #4',2007,25,86,719,'now'
);

INSERT INTO wine(No,Grape,Winery,Appelation,State,Name,Year,Price,Score,Cases,Drink
)
VALUES (500,'Chardonnay','Acacia','California','California','A by Acacia',2008,11,81,NULL,'now'
);

