INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (18129, STR_TO_DATE('28,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (51991, STR_TO_DATE('17,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (83085, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (70723, STR_TO_DATE('28,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (13355, STR_TO_DATE('19,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (52761, STR_TO_DATE('27,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (99002, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (58770, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (84665, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (55944, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (42166, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (16034, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (25906, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (27741, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64451, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (41028, STR_TO_DATE('6,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (73716, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (76667, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (21040, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (48332, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (35011, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (95962, STR_TO_DATE('26,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (44798, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (60270, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (21162, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (77406, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (32565, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (36343, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96619, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (86678, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (44330, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (91937, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (21545, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (29226, STR_TO_DATE('26,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (25121, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (54935, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (36423, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (83437, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (49854, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (99994, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (21622, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64861, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (33456, STR_TO_DATE('5,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (75468, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (56365, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (91192, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (82056, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (27192, STR_TO_DATE('28,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (59716, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (82795, STR_TO_DATE('8,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (26240, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (56724, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (70796, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (37636, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (63998, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (48981, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (66704, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (12698, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (79287, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (55690, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (94371, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (26148, STR_TO_DATE('19,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (11923, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (46598, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (76951, STR_TO_DATE('27,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (85858, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (85881, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (89937, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (66227, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (60240, STR_TO_DATE('17,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (86085, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (67314, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (10013, STR_TO_DATE('17,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (26741, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (38157, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (45873, STR_TO_DATE('5,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (37540, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (11891, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (61797, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (52369, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96430, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64301, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (45976, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39605, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (52013, STR_TO_DATE('5,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (88626, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (53376, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (15584, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (73437, STR_TO_DATE('1,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (24200, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (92252, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39685, STR_TO_DATE('28,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (61378, STR_TO_DATE('8,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96761, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (26198, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (78179, STR_TO_DATE('24,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (68890, STR_TO_DATE('27,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (75526, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 18
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (86162, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (13496, STR_TO_DATE('30,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (60469, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (50660, STR_TO_DATE('18,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64553, STR_TO_DATE('8,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (57784, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (84258, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (68199, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (78187, STR_TO_DATE('17,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (81517, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (18951, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (20411, STR_TO_DATE('8,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (55494, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (42162, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (49977, STR_TO_DATE('18,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (89638, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (73438, STR_TO_DATE('18,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96258, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (19258, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (12800, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (81368, STR_TO_DATE('17,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (70655, STR_TO_DATE('6,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (19002, STR_TO_DATE('19,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (31874, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (72207, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (65091, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (42833, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (72949, STR_TO_DATE('2,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (46248, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 11
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (38849, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (86861, STR_TO_DATE('26,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (32701, STR_TO_DATE('19,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (89182, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (68753, STR_TO_DATE('11,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39217, STR_TO_DATE('19,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96531, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (53922, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 2
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64477, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (99058, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (77032, STR_TO_DATE('28,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (15286, STR_TO_DATE('11,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (59774, STR_TO_DATE('2,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (35073, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (34910, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (17685, STR_TO_DATE('2,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (45062, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39109, STR_TO_DATE('2,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (37063, STR_TO_DATE('22,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (18567, STR_TO_DATE('13,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (37586, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (62707, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (28117, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (64574, STR_TO_DATE('2,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (40305, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (33060, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (12396, STR_TO_DATE('10,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (43103, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39575, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (70162, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (23034, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (79296, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 19
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (74741, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (98806, STR_TO_DATE('15,10,2007', '%d,%m,%Y'), 17
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (43752, STR_TO_DATE('5,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (47353, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (39829, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (87454, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (76663, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (85492, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 12
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (48647, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 3
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (61008, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (96402, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (35904, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (49845, STR_TO_DATE('31,10,2007', '%d,%m,%Y'), 20
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (46014, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (46876, STR_TO_DATE('6,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (34579, STR_TO_DATE('8,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (17729, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (74952, STR_TO_DATE('16,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (61948, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 5
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (41064, STR_TO_DATE('25,10,2007', '%d,%m,%Y'), 16
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (17947, STR_TO_DATE('27,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (20913, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (95514, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 10
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (24829, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (44590, STR_TO_DATE('12,10,2007', '%d,%m,%Y'), 1
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (65165, STR_TO_DATE('4,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (89588, STR_TO_DATE('9,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (53240, STR_TO_DATE('3,10,2007', '%d,%m,%Y'), 14
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (46674, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (67946, STR_TO_DATE('18,10,2007', '%d,%m,%Y'), 7
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (31233, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (15904, STR_TO_DATE('6,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (17488, STR_TO_DATE('20,10,2007', '%d,%m,%Y'), 6
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (97097, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 9
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (50512, STR_TO_DATE('27,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (11548, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (29908, STR_TO_DATE('14,10,2007', '%d,%m,%Y'), 13
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (20127, STR_TO_DATE('7,10,2007', '%d,%m,%Y'), 15
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (41963, STR_TO_DATE('29,10,2007', '%d,%m,%Y'), 8
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (16532, STR_TO_DATE('21,10,2007', '%d,%m,%Y'), 4
);

INSERT INTO receipts(RecieptNumber, Date, CustomerId
)
VALUES (34378, STR_TO_DATE('23,10,2007', '%d,%m,%Y'), 6
);

