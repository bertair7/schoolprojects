import java.io.*;
import java.util.*;
import java.sql.*;
import java.text.*;


public class InnReservations {
   public static final char ESC = 27;
   public static final String roomTable = "CREATE TABLE rooms ("
                  + "RoomCode CHAR(5), "
                  + "RoomName VARCHAR(30), "
                  + "Beds INTEGER, "
                  + "bedType VARCHAR(8), "
                  + "maxOcc INTEGER, "
                  + "basePrice FLOAT, "
                  + "decor VARCHAR(20), "
                  + "PRIMARY KEY (RoomCode))";

   public static final String reservationTable = "CREATE TABLE reservations ("
                  + "Code INTEGER, "
                  + "Room CHAR(5), "
                  + "CheckIn DATE, "
                  + "CheckOut DATE, "
                  + "Rate FLOAT, "
                  + "LastName VARCHAR(25), "
                  + "FirstName VARCHAR(25), "
                  + "Adults INTEGER, "
                  + "Kids INTEGER, "
                  + "FOREIGN KEY (Room) REFERENCES rooms(RoomCode), "
                  + "PRIMARY KEY (Room, CheckIn))";

   public static void main (String args[]) {
      Connection conn = null;
      String userID = null, pswd = null, url = null;
      Statement stmt = null;
      boolean roomsIsEmpty = true, reservationsIsEmpty = true;
      Scanner reader = null;

      try {
         File file = new File("ServerSettings.txt");
         FileReader fileReader = new FileReader(file);
	      BufferedReader bufferedReader = new BufferedReader(fileReader);
         url = bufferedReader.readLine();
         userID = bufferedReader.readLine();
         pswd = bufferedReader.readLine();

      }
      catch (IOException e) {
         System.out.println("Invalid ServerSettings.txt file.");
         e.printStackTrace();
      }

      try {
         // now connect to mySQL with user's own database
         System.out.println ("Connecting...");
         conn = DriverManager.getConnection(
         url + "?"
         + "user=" + userID + "&password=" + pswd);
         System.out.println ("connected.");
	
         // check if inn tables already exists
         DatabaseMetaData dbm = conn.getMetaData();
         ResultSet rs = dbm.getTables(null, null, "rooms", null);
         if(!rs.next()) {
            System.out.println("Creating rooms table");
            try {
               Statement s1 = conn.createStatement();
               s1.executeUpdate(roomTable);
               System.out.println("Created.");
            }
            catch (Exception ee) {
               System.out.println("ee96: " + ee);
            }
         }
         else {
            System.out.println("rooms table exists");
         }

         rs = dbm.getTables(null, null, "reservations", null);
         if(!rs.next()) {
            System.out.println("Creating reservations table");
            try {
	            Statement s1 = conn.createStatement();
	            s1.executeUpdate(reservationTable);
               System.out.println("Created.");
	    }
	    catch (Exception ee) {
	       System.out.println("ee96: " + ee);
	    }
         }
         else {
            System.out.println("reserations table exists");
         }

	 // Check if tables are emtpy
         stmt = conn.createStatement();

         rs = stmt.executeQuery("SELECT * FROM rooms");
         if(rs.first())
            roomsIsEmpty = false;
         rs = stmt.executeQuery("SELECT * FROM reservations");
         if(rs.first())
            reservationsIsEmpty = false;

         reader = new Scanner(System.in);
         listMenuOptions();
         String n = reader.next();

         while(!n.equals("E")) {
            if(n.equals("A")) {
               clearScreen();
               adminAccess(conn);
               clearScreen();
               listMenuOptions();
            }
            else if(n.equals("G")) {
               System.out.println(n);
               System.out.println("1");
               clearScreen();
               guestAccess(conn);
               clearScreen();
               listMenuOptions();
            }
            else if(n.equals("O")) {
               System.out.println(n);
               System.out.println("2");
               clearScreen();
               ownerAccess(conn);
               clearScreen();
               listMenuOptions();
            }
            else if(n.equals("C"))
               clearScreen();
            n = reader.next();
         }

      }

      catch (Exception ex) {
	 ex.printStackTrace( );
      }
      finally {
	 try {
	    //pstmt.close( );
	 }
	 catch (Exception e){}
	 try {
	    //rset.close( );
	 }
	 catch (Exception e){}
	 try {
            System.out.println("Closing connection...");
	    conn.close();
            System.out.println("Closed");
	 }
	 catch (Exception e){}	
      }

   }

   public static void adminAccess(Connection conn) throws Exception {
      Statement stmt = null;
      ResultSet rs = null, rs1 = null, rs2 = null;
      DatabaseMetaData dbm = conn.getMetaData();
      boolean dropped = false;

      Scanner reader = new Scanner(System.in);
      listAdminOptions();
      String n = reader.next();

      while(!n.equals("M")) {
         if(n.equals("S")) {
            // check if tables are empty or full or non-existent
            System.out.println("\n-------STATUS-------\n");
            stmt = conn.createStatement();
            rs1 = dbm.getTables(null, null, "rooms", null);
            rs2 = dbm.getTables(null, null, "reservations", null);

            if(!rs1.next()) {
               System.out.println("rooms table does not exist.");
            }
            else {
               rs = stmt.executeQuery("SELECT * FROM rooms");
               if(rs.first())
                  System.out.println("rooms table is not empty.");
               else
                  System.out.println("rooms table is empty.");
            }

            if(!rs2.next()) { 
               System.out.println("reservations table does not exist");
               n = reader.next();
               continue;  
            }
            else {
               rs = stmt.executeQuery("SELECT * FROM reservations");
               if(rs.first())
                  System.out.println("reservations table is not empty.");
               else
                  System.out.println("reservations table is empty.");
            }
            // count number of rows in them
            rs = stmt.executeQuery("SELECT COUNT(*) AS COUNT FROM reservations");
            while(rs.next()) {
               System.out.println("Total rows in reservations: " + rs.getInt("COUNT"));
            }

            rs = stmt.executeQuery("SELECT COUNT(*) AS COUNT FROM rooms");
            while(rs.next()) {
               System.out.println("Total rows in rooms: " + rs.getInt("COUNT"));
            }
         }

         else if(n.equals("R1")) {
            if(dropped) {
               System.out.println("Tables do not exist");
               n = reader.next();
               continue;
            }
            String query = "SELECT * FROM reservations";
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery(query);

            int i = 1; 
            System.out.println("Id\tCode   \tRoom   \tCheckIn   \tCheckOut"
	       + "   \tRate   \tLastName   \tFirstName\tAdults\tKids");

            while (rs.next ()){
              System.out.print(i + "\t");
              System.out.print (rs.getInt ("Code") + "\t");
              System.out.print (rs.getString ("Room") + "\t");
              System.out.print (rs.getDate ("CheckIn") + "\t");
              System.out.print (rs.getDate ("CheckOut") + "\t");
              System.out.print (rs.getFloat ("Rate") + "\t");
              System.out.print (rs.getString ("LastName") + "   \t");
              System.out.print (rs.getString ("FirstName") + "   \t");
              System.out.print (rs.getInt ("Adults") + "\t\t");
              System.out.print (rs.getInt ("Kids") + "\t\t");
              System.out.println( );
              i++;
            }
         }

         else if(n.equals("R2")) {
            if(dropped) {
               System.out.println("Tables do not exist");
               n = reader.next();
               continue;
            }
            String query = "SELECT * FROM rooms";
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery(query);

            int i = 1;
            System.out.println("Id\tCode\tRoomName\t\t\tBeds\tbedType\t"
               + "maxOcc\tbase$\tdecor");

            while (rs.next ()){
              System.out.print(i + "\t");
              System.out.print (rs.getString ("RoomCode") + "\t");
              System.out.print (rs.getString ("RoomName") + "      \t");
              System.out.print (rs.getInt ("Beds") + "\t");
              System.out.print (rs.getString ("bedType") + "\t");
              System.out.print (rs.getInt ("maxOcc") + "\t");
              System.out.print (rs.getFloat ("basePrice") + "\t");
              System.out.print (rs.getString ("decor") + "\t");
              System.out.println( );
              i++;
            }

         }

         else if(n.equals("C")) {
            if(dropped) {
               System.out.println("Tables do not exist");
               n = reader.next();
               continue;
            }

            String query = null;

            System.out.println("Clearing reservations table");
            query = "DELETE FROM reservations";
            stmt = conn.prepareStatement(query);
            stmt.executeUpdate(query);
            System.out.println("reservations cleared");

            System.out.println("Clearing rooms table");
            query = "DELETE FROM rooms";
            stmt = conn.prepareStatement(query);
            stmt.executeUpdate(query);
            System.out.println("rooms cleared");
         }

         else if(n.equals("L")) {
 
            stmt = conn.createStatement();
            rs1 = dbm.getTables(null, null, "rooms", null);
            rs2 = dbm.getTables(null, null, "reservations", null);

            if(!rs1.next()) {
               System.out.println("rooms table does not exist, creating rooms table...");
               Statement s1 = conn.createStatement();
               s1.executeUpdate(roomTable);
               System.out.println("Created.");
            }

            if(!rs2.next()) {
               System.out.println("reservations table does not exist, creating reservations table");
               Statement s1 = conn.createStatement();
               s1.executeUpdate(reservationTable);
               System.out.println("Created.");
            }

            rs1 = stmt.executeQuery("SELECT * FROM rooms");
            Statement stmt1 = conn.createStatement();
            rs2 = stmt1.executeQuery("SELECT * FROM reservations");
            if(rs1.first() && rs2.first()) {
               System.out.println("rooms table is full.");
               n = "S";
               continue;
            }
            else {
               System.out.println("Populating tables...");

               try {
                  File file = new File("INN-build-rooms.sql");
                  FileReader fileReader = new FileReader(file);
                  BufferedReader bufferedReader = new BufferedReader(fileReader);
                  String query = "";
                  while(bufferedReader.ready()) {
                     stmt = conn.createStatement();
                     query += bufferedReader.readLine();
                     query += " " + bufferedReader.readLine();
                     stmt.executeUpdate(query);
                     query = "";
                  }

               }
               catch (IOException e) {
                  System.out.println("Invalid INN-build-rooms.sql file.");
                  e.printStackTrace();
               }

               try {
                  File file = new File("INN-build-reservations.sql");
                  FileReader fileReader = new FileReader(file);
                  BufferedReader bufferedReader = new BufferedReader(fileReader);
                  String query = "";
                  while(bufferedReader.ready()) {
                     stmt = conn.createStatement();
                     query += bufferedReader.readLine();
                     query += bufferedReader.readLine();
                     query += " " + bufferedReader.readLine();
                     query += bufferedReader.readLine();
                     bufferedReader.readLine();
                     System.out.println(query);
                     stmt.executeUpdate(query);
                     query = "";
                  }

               }
               catch (IOException e) {
                  System.out.println("Invalid INN-build-reservation.sql file.");
                  e.printStackTrace();
               } 
                
            }
            dropped = false;
         }
         else if(n.equals("D")) {
            if(dropped) {
               System.out.println("Tables do not exist");
               n = reader.next();
               continue;
            }
            System.out.println("Droping tables...\n");

            String query = null;

            stmt = conn.createStatement();
            query = "DROP TABLE reservations";
            stmt.executeUpdate(query);

            query = "DROP TABLE rooms";
            stmt.executeUpdate(query);
            n = "S";
            dropped = true;
            continue;
         }
 
         else 
            System.out.println("Invalid option");
         n = reader.next();
      }
      
   }

   public static void ownerAccess(Connection conn) throws Exception {
      Statement stmt = null;
      ResultSet rs = null, rs1 = null, rs2 = null;
      DatabaseMetaData dbm = conn.getMetaData();

      Scanner reader = new Scanner(System.in);
      listOwnerOptions();
      String n = reader.next();

      while(!n.equals("M")) {
         if(n.equals("O")) {  //OR-1 Occupancy overview
            System.out.println("Details for one date (D) or date range (R)?");
            n = reader.next();

            if(n.equals("D")) {
               System.out.print("Input date (YYYY-MM-DD): ");
               String date = reader.next();
               String query = "SELECT DISTINCT(r.Room), MAX(('" + date + "' BETWEEN "
               + "r.CheckIn AND r.Checkout)) AS 'Occupied' FROM reservations r, "
               + "rooms ro WHERE r.Room = ro.RoomCode GROUP BY r.Room;";

               stmt = conn.createStatement();
               rs = stmt.executeQuery(query);
               
               System.out.println("\nId\tRoom\tOccupied");
               int i = 1;

               while (rs.next()){
                  System.out.print(i + "\t");
                  System.out.print(rs.getString ("Room") + "\t");
                  int occ = rs.getInt("Occupied");
                  
                  if(occ == 0)
                     System.out.print("No\t");
                  else if(occ == 1) 
                     System.out.print("Yes\t");

                  i++;
                  System.out.println();
               }

               System.out.println("\nIf desired, input number for room reservation"
               + " info, else enter Q to return");
               n = reader.next();
               if (n.equals("Q")) {
                  clearScreen();
                  listOwnerOptions();
                  reader.nextLine();
               }
               else {
                  String room = selectedRoom(n);
                  query = "SELECT * FROM reservations WHERE Room = '" + room 
                  + "' AND '" + date + "' BETWEEN CheckIn and Checkout;";

                  rs1 = stmt.executeQuery(query);
                  System.out.println("Code\tRoom\tCheckIn\t\tCheckout\tRate\tLastName\t" 
                  + "FirstName\tAdults\tKids");
                  while(rs1.next()) {
                     System.out.print(rs1.getInt("CODE") + "\t");
                     System.out.print(rs1.getString("Room") + "\t");
                     System.out.print(rs1.getString("CheckIn") + "\t");
                     System.out.print(rs1.getString("Checkout") + "\t");
                     System.out.print(rs1.getFloat("Rate") + "\t");
                     System.out.print(rs1.getString("LastName") + "   \t");
                     System.out.print(rs1.getString("FirstName") + "   \t");
                     System.out.print(rs1.getInt("Adults") + "\t");
                     System.out.print(rs1.getInt("Kids") + "\t");
                     System.out.println();
                  }
               }
            }
            else if (n.equals("R")) {
               System.out.println("Not implemented :(");
               /*System.out.print("Date 1 (YYYY-MM-DD): ");
               String date1 = reader.next();
               System.out.print("Date 2 (YYYY-MM-DD): ");
               String date2 = reader.next();
               
               String dates = date1 + " " + date2;
               if (!checkDates(dates)) {
                  System.out.print("Invalid dates");
                  continue;
               }

               String query = "SELECT DISTINCT(r.Room), SUM(datediff('" + date1
               + "
               + "r.CheckIn AND r.Checkout)) AS 'Occupied' FROM reservations r, "
               + "rooms ro WHERE r.Room = ro.RoomCode GROUP BY r.Room;";

               stmt = conn.createStatement();
               rs = stmt.executeQuery(query);
               
               System.out.println("\nId\tRoom\tOccupied");
               int i = 1;

               while (rs.next()){
                  System.out.print(i + "\t");
                  System.out.print(rs.getString ("Room") + "\t");
                  int occ = rs.getInt("Occupied");
                  
                  if(occ == 0)
                     System.out.print("No\t");
                  else if(occ == 1) 
                     System.out.print("Yes\t");

                  i++;
                  System.out.println();
               }*/
            }
            else {
               System.out.println("Invalid option");
            }
         }
         else if(n.equals("$")) {  //OR-2 View revenue
            System.out.println("Not implemented :(");
         }
         else if(n.equals("R1")) { //OR-4 Review rooms
            showRooms(conn);
            System.out.println("I - Info of Rooms");
            System.out.println("L - List of Reservations");
            n = reader.next();
            
            if (n.equals("L")) {
               System.out.print("Select room number (1-10): ");
               String num = reader.next();
               String room = selectedRoom(num);
               String query = "SELECT * FROM reservations WHERE Room = '" + room 
               + "' ORDER BY CheckIn;";

               stmt = conn.createStatement();
               rs = stmt.executeQuery(query);

               System.out.println("Code\tRoom\tCheckIn\t\tCheckout\tRate\tLastName\t" 
               + "FirstName\tAdults\tKids");
               while(rs.next()) {
                  System.out.print(rs.getInt("CODE") + "\t");
                  System.out.print(rs.getString("Room") + "\t");
                  System.out.print(rs.getString("CheckIn") + "\t");
                  System.out.print(rs.getString("Checkout") + "\t");
                  System.out.print(rs.getFloat("Rate") + "\t");
                  System.out.print(rs.getString("LastName") + "   \t");
                  System.out.print(rs.getString("FirstName") + "   \t");
                  System.out.print(rs.getInt("Adults") + "\t");
                  System.out.print(rs.getInt("Kids") + "\t");
                  System.out.println();
               }
               listOwnerOptions();
               reader.nextLine();
            }
            else if (n.equals("I")) {
               System.out.println("Not implemented :(");
            }
            else {
               System.out.println("Invalid option");
               listOwnerOptions();
            }
         }
         else if(n.equals("R2")) { //OR-3 Review reservations
            String query = null;
            System.out.print("Date 1 (YYYY-MM-DD): ");
            String date1 = reader.next();
            System.out.print("Date 2 (YYYY-MM-DD): ");
            String date2 = reader.next();

            String dates = date1 + " " + date2;
            if (!checkDates(dates)) {
               System.out.print("Invalid dates");
               continue;
            }

            showRooms(conn);
            System.out.print("Which room? (If no room, enter 0) ");
            String i = reader.next();
            if (!i.equals("0")) {
               String room = selectedRoom(i);
               query = "SELECT * FROM reservations WHERE Room = '" + room
               + "' AND ((CheckIn <= '" + date1 + "' AND Checkout >= '" + date2
               + "') OR (CheckIn <= '" + date2 + "' AND Checkout >= '" + date2
               + "') OR (CheckIn <= '" + date1 + "' AND Checkout >= '" + date1
               + "')) ORDER BY Room;";
            }
            else {
               query = "SELECT * FROM reservations WHERE ((CheckIn <= '" + date1 
               + "' AND Checkout >= '" + date2 + "') OR (CheckIn <= '" + date2 
               + "' AND Checkout >= '" + date2 + "') OR (CheckIn <= '" + date1 
               + "' AND Checkout >= '" + date1 + "')) ORDER BY Room;";
            }
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);

            System.out.println("Code\tRoom\tCheckIn\t\tCheckout\tRate\tLastName\t" 
            + "FirstName\tAdults\tKids");
            while(rs.next()) {
               System.out.print(rs.getInt("CODE") + "\t");
               System.out.print(rs.getString("Room") + "\t");
               System.out.print(rs.getString("CheckIn") + "\t");
               System.out.print(rs.getString("Checkout") + "\t");
               System.out.print(rs.getFloat("Rate") + "\t");
               System.out.print(rs.getString("LastName") + "   \t");
               System.out.print(rs.getString("FirstName") + "   \t");
               System.out.print(rs.getInt("Adults") + "\t");
               System.out.print(rs.getInt("Kids") + "\t");
               System.out.println();
            }
            listOwnerOptions();
            reader.nextLine();
         }
         else {
            System.out.println("Invalid option");
         }
         n = reader.next();
      }
   }

   public static void showRooms(Connection conn) throws Exception {
      Statement stmt = conn.createStatement();
      ResultSet rs = null;
      String q = "SELECT DISTINCT(Room) FROM reservations;";
      rs = stmt.executeQuery(q);

      System.out.println("Id\tRoom");
      int i = 1;
   
      while (rs.next()) {
         System.out.print(i + "\t");
         System.out.print(rs.getString("Room") + "\t");
         System.out.println();
         i++;
      }
   }

   public static void guestAccess(Connection conn) throws Exception {
      Statement stmt = null;
      ResultSet rs = null, rs1 = null, rs2 = null;
      DatabaseMetaData dbm = conn.getMetaData();

      Scanner reader = new Scanner(System.in);
      listGuestOptions();
      String n = reader.next();

      while(!n.equals("M")) {
         if(n.equals("R")) {
            stmt = conn.createStatement();
            rs1 = dbm.getTables(null, null, "rooms", null);


            if(!rs1.next()) {
               System.out.println("rooms table does not exist.");
               n = reader.next();
               continue;
            }
            else {
              
               displayRooms(conn, rs, stmt);
               System.out.println("# - Select for more information about the room");
               System.out.println("B - back to guest access");
 
               n = reader.next();
               while(!n.equals("B")) {
                  String val = selectedRoom(n);
                  if(val != null) {
                     String query = "SELECT RoomName, Beds, bedType, maxOcc,  decor FROM rooms WHERE RoomCode = '" + val + "'";
                     rs = stmt.executeQuery(query);
                     
                     rs.next();
                     System.out.println("\nRoom Name: " + rs.getString("RoomName"));
                     System.out.println("Number of Beds: " + rs.getString("Beds"));
                     System.out.println("Bed Type: " + rs.getString("bedType"));
                     System.out.println("Max Occupants: " + rs.getString("maxOcc"));
                     System.out.println("Decor: " + rs.getString("Decor"));

                     displayRoomOptions();

                     n = reader.next();
                     while(true) {
                        if(n.equals("X")) {
                           checkAvailability(conn, val);
                        }
                        else if(n.length() == 1 && Character.getNumericValue('a') <= Character.getNumericValue(n.charAt(0)) && Character.getNumericValue(n.charAt(0)) <= Character.getNumericValue('j'))
                           break;
                        else if(n.equals("R")) 
                           displayRooms(conn, rs, stmt);
                        else if(n.equals("B")) {
                           break;
                        }
                        else
                           System.out.println("Invalid Option");
                        n = reader.next();    
                     }
                  }
                  else {
                     System.out.println("Invalid option");
                     n = reader.next();
                  }
               }
            }
         }

         else
            System.out.println("Invalid option");

         listGuestOptions();
         n = reader.next();
      }

   }

   public static void checkAvailability(Connection conn, String roomVal) throws Exception {
      Statement stmt = null;
      Scanner reader = new Scanner(System.in);
      String n = null;
      boolean validDates = false;

      System.out.println("Please enter valid checkin and checkout  dates in the format <YYYY-MM-DD YYYY-MM-DD>");
      System.out.println("E - Exit");
      n = reader.nextLine();

      while(!n.equals("E")) {
         validDates = checkDates(n);
         if(validDates) {
            ArrayList<java.util.Date> d = datesBetweenDays(n);
            availability(d, conn, roomVal);
            validDates = false;
         }

         else
            System.out.println("Invalid dates: format 1997-02-11");
         n = reader.nextLine();
         
      }
      
   }

   public static void availability(ArrayList<java.util.Date> dates, Connection conn, String roomVal) throws Exception {
      Statement stmt = null;
      ResultSet rs = null;
      DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");

      for(int i = 0; i < dates.size(); i++) {
         String date = df1.format(dates.get(i));
         String query = "SELECT  FROM reservations, rooms WHERE RoomCode = Room AND RoomCode = '" + roomVal +"' AND ('" 
                        + date + "' < CheckIn OR '" + date + "' > CheckOut)";
      }
   }

   public static ArrayList<java.util.Date> datesBetweenDays(String dlist) {
      String[] tokens = dlist.split(" ");
      ArrayList<java.util.Date> dates = new ArrayList<java.util.Date>();
      DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");

      java.util.Date date1 = null;
      java.util.Date date2 = null;

      try {
          date1 = df1.parse(tokens[0]);
          date2 = df1.parse(tokens[1]);
      } catch (ParseException e) {
          e.printStackTrace();
      }

      Calendar cal1 = Calendar.getInstance();
      cal1.setTime(date1);


      Calendar cal2 = Calendar.getInstance();
      cal2.setTime(date2);

      while(!cal1.after(cal2))
      {
          dates.add(cal1.getTime());
          cal1.add(Calendar.DATE, 1);
      }
      return dates;
   }

   public static boolean checkDates(String dates) throws Exception {
      String[] tokens = dates.split(" ");
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
      java.util.Date d1;
      java.util.Date d2;
      df.setLenient(false);
      if(tokens.length != 2) return false;
      for(int i = 0; i < 2; i++) {
         try {
            //System.out.println(tokens[i]);
            df.parse(tokens[i].trim());
         } catch (ParseException e) {
           return false;
         }
      }
      d1 = df.parse(tokens[0]);
      d2 = df.parse(tokens[1]);
      if(d1.compareTo(d2) == -1)
         return true;
      return false;
   }

   public static void displayRoomOptions() {
      System.out.println("\nX - Check Availability");
      System.out.println("# - Select room for more information");
      System.out.println("B - Back to guest access");
      System.out.println("R - Display rooms");
   }

   public static void displayRooms(Connection conn, ResultSet rs, Statement stmt) throws Exception {
      char a = 'a';
      rs = stmt.executeQuery("SELECT RoomName FROM rooms");
      System.out.println("----------ROOMS---------\n");
      while (rs.next ()){
         System.out.print(a++ + "\t");
         System.out.println(rs.getString ("RoomName"));
      }
      System.out.println("\n--------------------\n");

   }

   public static String selectedRoom(String num) {
      String code = null;
      switch(num) {
         case "a": code = "AOB"; break;
         case "b": code = "CAS"; break;
         case "c": code = "FNA"; break;
         case "d": code = "HBB"; break;
         case "e": code = "IBD"; break;
         case "f": code = "IBS"; break;
         case "g": code = "MWC"; break;
         case "h": code = "RND"; break;
         case "i": code = "RTE"; break;
         case "j": code = "TAA"; break;
         case "1": code = "AOB"; break;
         case "2": code = "CAS"; break;
         case "3": code = "FNA"; break;
         case "4": code = "HBB"; break;
         case "5": code = "IBD"; break;
         case "6": code = "IBS"; break;
         case "7": code = "MWC"; break;
         case "8": code = "RND"; break;
         case "9": code = "RTE"; break;
         case "10": code = "TAA"; break;
         default: break;
      }
      return code;
   }
   
   public static void listGuestOptions() {
      System.out.println("\nGuest Menu\n");
      System.out.println("R - Display list of rooms and rates\n");
   }

   public static void listAdminOptions() {
      System.out.println("\nAdmin Menu\n");
      System.out.println("S - Display current status\n");
      System.out.println("R1 - Display reservations table\n");
      System.out.println("R2 - Display rooms table\n");
      System.out.println("C - Clear tables\n");
      System.out.println("D - Drop tables\n");
      System.out.println("L - Load tables\n");
      System.out.println("M - Return to the main menu\n");
   }

   public static void listOwnerOptions() {
      System.out.println("\nOwner Menu\n");
      System.out.println("O - Display occupancy overview\n");
      System.out.println("$ - Display revenue\n");
      System.out.println("R1 - Display rooms\n");
      System.out.println("R2 - Display reservations\n");
      System.out.println("M - Return to the main menu\n");
   }

   public static void listMenuOptions() {
      System.out.println("\nWelcome to our INN system!\n");
      System.out.println("A - Admin access\n");
      System.out.println("O - Owner access\n");
      System.out.println("G - Guest access\n");
      System.out.println("E - Exit\n");
   }

   public static void clearScreen() throws Exception {
         Console c = System.console();
         if (c == null) {
            System.err.println("no console");
            System.exit(1);
         }

         c.writer().print(ESC + "[2J");
         c.flush();

         c.writer().print(ESC + "[1;1H");
         c.flush();

   }

}
