# Lab08-CPE365
Lab 8 CPE 365

Test files are in tests folder. The Jar file to connect JDBC is in that folder also. 
Before you run the java files you need to do run the command:
'export CLASSPATH=~<YOUR_PATH_TO_FOLDER>tests/mysql-connector-java-5.1.44/mysql-connector-java-5.1.44-bin.jar:$CLASSPATH'

