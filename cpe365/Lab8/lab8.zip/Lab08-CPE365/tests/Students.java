import java.io.*;
import java.util.*;
import java.sql.*;

class Students {	
   public static void main (String args []){
      Connection conn = null;
      PreparedStatement  stmt = null;
      ResultSet rset = null; 
      String id = null, pword = null;

      if (args.length != 2){
         System.out.println("USAGE: two arguments required: "
	    + " <ID> <PASSWORD>");
         System.exit(-1);
      }   	  

      try {
         id = args[0].trim();
         pword = args[1].trim();

         Class.forName ("com.mysql.jdbc.Driver").newInstance(); 
         System.out.println ("Driver class found and loaded.");   

         System.out.println ("Connecting...");
         conn = DriverManager.getConnection(
           "jdbc:mysql://cslvm74.csc.calpoly.edu/students?"
           + "user=" + id + "&password=" + pword);
         System.out.println ("connected.");      
	 
         String query =          	
	    "select * " +
	    "from   list S, teachers T " +
	    "where  S.classroom = T.classroom"; 
         System.out.println("QUERY STRING is:\n" + query);
         stmt = conn.prepareStatement(query);
         	
         rset = stmt.executeQuery();
         	
         int i = 1; 
         System.out.println("\tFirstName    \tLastName\tgrade"
	    + "\tclassroom\tFirst    \tLast\tclassroom");
         while (rset.next ()){
            System.out.print(i + "\t");
            System.out.print (rset.getString ("FirstName") + "\t");
            System.out.print (rset.getString ("LastName") + "\t");
            System.out.print (rset.getInt ("grade") + "\t");
            System.out.print (rset.getInt ("S.classroom") + "\t");
            System.out.print (rset.getString ("First") + "\t");
            System.out.print (rset.getString ("Last") + "\t");
            System.out.print (rset.getInt ("T.classroom") + "\t");
            System.out.println( );
            i++;
         } 
         rset.close( );
      } 
      catch (Exception ex){
  	     ex.printStackTrace( );
      }
      finally {
      	 try {
             stmt.close( );
             conn.close( ); 
         }
         catch (Exception ex) {
   	        ex.printStackTrace( );    
   	 }    	
      }    	
  
   } 
   
} 
