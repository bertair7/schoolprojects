#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "globals.h"
#include "os.h"
#include "synchro.h"

extern system_t sysArray;

semaphore_t full, empty;
mutex_t m;
uint8_t items;
uint16_t pRate, cRate;

void led_on() {
   asm volatile ("LDI R31, 0x00");
   asm volatile ("LDI R30, 0x24");
   asm volatile ("LD R25, Z"); // Load (Z) into R25.
   asm volatile ("SBR R25, 0x80"); // Set bit 7.
   asm volatile ("ST Z, R25"); // Store into Z location whatever is in R25.

   asm volatile ("LDI R31, 0x00");
   asm volatile ("LDI R30, 0x25");
   asm volatile ("LD R25, Z"); // Load (Z) into R25.
   asm volatile ("SBR R25, 0x80"); // Set bit 7.
   asm volatile ("ST Z, R25"); // Store into Z location whatever is in R25.
}

void led_off() {
   asm volatile ("LDI R31, 0x00");
   asm volatile ("LDI R30, 0x24");
   asm volatile ("LD R25, Z"); // Load (Z) into R25.
   asm volatile ("SBR R25, 0x80"); // Set bit 7.
   asm volatile ("ST Z, R25"); // Store into Z location whatever is in R25.

   asm volatile ("LDI R31, 0x00");
   asm volatile ("LDI R30, 0x25");
   asm volatile ("LD R25, Z"); // Load (Z) into R25.
   asm volatile ("CBR R25, 0x80"); // Clear bit 7.
   asm volatile ("ST Z, R25"); // Store into Z location whatever is in R25.
}

void blink(uint16_t *delay) {

   while(1) {
      //check if producer is waiting (buffer full)
      if (items == 10)
         led_off();
      //check if producer is producing (available buffer)
      else
         led_on();
   }
}

void stats(uint8_t *str) {
   //_delay_ms(1500);
   clear_screen();

   while(1) {
      clear_screen();
      set_color(YELLOW);
      set_cursor(1, 1);
      print_string(str);

      set_cursor(2, 1);
      set_color(GREEN);
      print_string("Time: ");
      print_int(get_time());

      set_cursor(4, 1);
      set_color(CYAN);
      print_string("Number of threads: ");
      print_int(get_num_threads());

      //Thread 1
      set_cursor(6, 1);
      set_color(RED);
      print_string("Thread 1: ");
      print_string(sysArray.array[0].name);
      set_cursor(7, 1);
      set_color(RED);
      print_string("   ID - ");
      print_hex(sysArray.array[0].thread_id);
      set_cursor(8, 1);
      set_color(RED);
      print_string("   PC - ");
      print_string(sysArray.array[0].stackBase);
      set_cursor(9, 1);
      set_color(RED);
      print_string("   Stack usage - ");
      print_string(sysArray.array[0].stack);
      set_cursor(10, 1);
      set_color(RED);
      print_string("   Stack size - ");
      print_int(sysArray.array[0].size);
      set_cursor(11, 1);
      set_color(RED);
      print_string("   Stack top - ");
      print_string(sysArray.array[0].stackPtr);
      set_cursor(12, 1);
      set_color(RED);
      print_string("   Stack base - ");
      print_string(sysArray.array[0].stackBase);
      set_cursor(13, 1);
      set_color(RED);
      print_string("   Stack end - ");
      print_string(sysArray.array[0].stackPtr + sysArray.array[0].size);
      set_cursor(14, 1);
      set_color(RED);
      print_string("   Thread state - ");
      print_state(sysArray.array[0].state);
      set_cursor(15, 1);
      set_color(RED);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[0].sched_count);

      //Thread 2
      set_cursor(17, 1);
      set_color(BLUE);
      print_string("Thread 2: ");
      print_string(sysArray.array[1].name);
      set_cursor(18, 1);
      set_color(BLUE);
      print_string("   ID - ");
      print_hex(sysArray.array[1].thread_id);
      set_cursor(19, 1);
      set_color(BLUE);
      print_string("   PC - ");
      print_string(sysArray.array[1].stackBase);
      set_cursor(20, 1);
      set_color(BLUE);
      print_string("   Stack usage - ");
      print_string(sysArray.array[1].stack);
      set_cursor(21, 1);
      set_color(BLUE);
      print_string("   Stack size - ");
      print_int(sysArray.array[1].size);
      set_cursor(22, 1);
      set_color(BLUE);
      print_string("   Stack top - ");
      print_string(sysArray.array[1].stackPtr);
      set_cursor(23, 1);
      set_color(BLUE);
      print_string("   Stack base - ");
      print_string(sysArray.array[1].stackBase);
      set_cursor(24, 1);
      set_color(BLUE);
      print_string("   Stack end - ");
      print_string(sysArray.array[1].stackPtr + sysArray.array[1].size);
      set_cursor(25, 1);
      set_color(BLUE);
      print_string("   Thread state - ");
      print_state(sysArray.array[1].state);
      set_cursor(26, 1);
      set_color(BLUE);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[1].sched_count);

      //Thread 3
      set_cursor(28, 1);
      set_color(RED);
      print_string("Thread 3: ");
      print_string(sysArray.array[2].name);
      set_cursor(29, 1);
      set_color(RED);
      print_string("   ID - ");
      print_hex(sysArray.array[2].thread_id);
      set_cursor(30, 1);
      set_color(RED);
      print_string("   PC - ");
      print_string(sysArray.array[2].stackBase);
      set_cursor(31, 1);
      set_color(RED);
      print_string("   Stack usage - ");
      print_string(sysArray.array[2].stack);
      set_cursor(32, 1);
      set_color(RED);
      print_string("   Stack size - ");
      print_int(sysArray.array[2].size);
      set_cursor(33, 1);
      set_color(RED);
      print_string("   Stack top - ");
      print_string(sysArray.array[2].stackPtr);
      set_cursor(34, 1);
      set_color(RED);
      print_string("   Stack base - ");
      print_string(sysArray.array[2].stackBase);
      set_cursor(35, 1);
      set_color(RED);
      print_string("   Stack end - ");
      print_string(sysArray.array[2].stackPtr + sysArray.array[2].size);
      set_cursor(36, 1);
      set_color(RED);
      print_string("   Thread state - ");
      print_state(sysArray.array[2].state);
      set_cursor(37, 1);
      set_color(RED);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[2].sched_count);

      //Thread 4
      set_cursor(39, 1);
      set_color(BLUE);
      print_string("Thread 4: ");
      print_string(sysArray.array[3].name);
      set_cursor(40, 1);
      set_color(BLUE);
      print_string("   ID - ");
      print_hex(sysArray.array[3].thread_id);
      set_cursor(41, 1);
      set_color(BLUE);
      print_string("   PC - ");
      print_string(sysArray.array[3].stackBase);
      set_cursor(42, 1);
      set_color(BLUE);
      print_string("   Stack usage - ");
      print_string(sysArray.array[3].stack);
      set_cursor(43, 1);
      set_color(BLUE);
      print_string("   Stack size - ");
      print_int(sysArray.array[3].size);
      set_cursor(44, 1);
      set_color(BLUE);
      print_string("   Stack top - ");
      print_string(sysArray.array[3].stackPtr);
      set_cursor(45, 1);
      set_color(BLUE);
      print_string("   Stack base - ");
      print_string(sysArray.array[3].stackBase);
      set_cursor(46, 1);
      set_color(BLUE);
      print_string("   Stack end - ");
      print_string(sysArray.array[3].stackPtr + sysArray.array[3].size);
      set_cursor(47, 1);
      set_color(BLUE);
      print_string("   Thread state - ");
      print_state(sysArray.array[3].state);
      set_cursor(48, 1);
      set_color(BLUE);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[3].sched_count);

      //Thread 5
      set_cursor(50, 1);
      set_color(RED);
      print_string("Thread 5: ");
      print_string(sysArray.array[4].name);
      set_cursor(51, 1);
      set_color(RED);
      print_string("   ID - ");
      print_hex(sysArray.array[4].thread_id);
      set_cursor(52, 1);
      set_color(RED);
      print_string("   PC - ");
      print_string(sysArray.array[4].stackBase);
      set_cursor(53, 1);
      set_color(RED);
      print_string("   Stack usage - ");
      print_string(sysArray.array[4].stack);
      set_cursor(54, 1);
      set_color(RED);
      print_string("   Stack size - ");
      print_int(sysArray.array[4].size);
      set_cursor(55, 1);
      set_color(RED);
      print_string("   Stack top - ");
      print_string(sysArray.array[4].stackPtr);
      set_cursor(56, 1);
      set_color(RED);
      print_string("   Stack base - ");
      print_string(sysArray.array[4].stackBase);
      set_cursor(57, 1);
      set_color(RED);
      print_string("   Stack end - ");
      print_string(sysArray.array[4].stackPtr + sysArray.array[4].size);
      set_cursor(58, 1);
      set_color(RED);
      print_string("   Thread state - ");
      print_state(sysArray.array[4].state);
      set_cursor(59, 1);
      set_color(RED);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[4].sched_count);

      //Thread 6
      set_cursor(61, 1);
      set_color(BLUE);
      print_string("Thread 6: ");
      print_string(sysArray.array[5].name);
      set_cursor(62, 1);
      set_color(BLUE);
      print_string("   ID - ");
      print_hex(sysArray.array[5].thread_id);
      set_cursor(63, 1);
      set_color(BLUE);
      print_string("   PC - ");
      print_string(sysArray.array[5].stackBase);
      set_cursor(64, 1);
      set_color(BLUE);
      print_string("   Stack usage - ");
      print_string(sysArray.array[5].stack);
      set_cursor(65, 1);
      set_color(BLUE);
      print_string("   Stack size - ");
      print_int(sysArray.array[5].size);
      set_cursor(66, 1);
      set_color(BLUE);
      print_string("   Stack top - ");
      print_string(sysArray.array[5].stackPtr);
      set_cursor(67, 1);
      set_color(BLUE);
      print_string("   Stack base - ");
      print_string(sysArray.array[5].stackBase);
      set_cursor(68, 1);
      set_color(BLUE);
      print_string("   Stack end - ");
      print_string(sysArray.array[5].stackPtr + sysArray.array[5].size);
      set_cursor(69, 1);
      set_color(BLUE);
      print_string("   Thread state - ");
      print_state(sysArray.array[5].state);
      set_cursor(70, 1);
      set_color(BLUE);
      print_string("   Scheduled count - ");
      print_int(sysArray.array[5].sched_count);

   }
}

void producer(uint16_t *v) {
   
   while (1) {
      //produce item

      sem_wait(&empty);
      mutex_lock(&m);

      //add item to buffer
      items++;
      set_cursor(68, 11);
      set_color(YELLOW);
      print_string("-->");

      mutex_unlock(&m);
      sem_signal(&full);

      thread_sleep(cRate/2);
      
      set_cursor(68, 11);
      print_string("   ");

      thread_sleep(cRate/2);
   }
}

void consumer(uint16_t *v) {
   
   while (1) {
      sem_wait(&full);
      mutex_lock(&m);

      //remove item from buffer
      items--;
      set_cursor(85, 11);
      set_color(YELLOW);
      print_string("-->");

      mutex_unlock(&m);
      sem_signal(&empty);

      //consume item
      thread_sleep(pRate/2);

      set_cursor(85, 11);
      print_string("   ");

      thread_sleep(pRate/2);
   }
}

void bounded_buffers(uint16_t *v) {
   uint8_t i;

   while(1) {
      set_cursor(72, 10);
      set_color(MAGENTA);
      print_string("------------");
      set_cursor(73, 10);
      set_color(MAGENTA);
      print_string("|          |");
      set_cursor(74, 10);
      set_color(MAGENTA);
      print_string("------------");
      
      //draw items in buffer
      set_cursor(73, 11);
      for (i = 0; i < items; i++) {
         set_color(MAGENTA);
         print_string("*");
      }
   }
}

void main(void) {
   uint16_t delay = 50, var = 0;
   uint8_t buffers = 10;
   uint8_t string[15] = "Program 3";

   os_init();

   create_thread("blink", (uint16_t)blink, (void*)&delay, 50);
   create_thread("stats", (uint16_t)stats, (void*)string, 200);
   create_thread("producer", (uint16_t)producer, (void*)&var, 200);
   create_thread("consumer", (uint16_t)consumer, (void*)&var, 200);
   create_thread("bounded", (uint16_t)bounded_buffers, (void*)&var, 200);

   mutex_init(&m);
   sem_init(&full, 0);
   sem_init(&empty, buffers);
   items = 0;
   cRate = 1000;
   pRate = 1000;

   os_start();
   sei();
   while (1) {}
}
