#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "synchro.h"
#include "globals.h"
#include "os.h"

extern system_t sysArray;

int8_t find_next_index(uint8_t id, uint8_t list[10]) {
   int8_t i;

   for (i = 0; i < 10; i++) {
      if (list[i] == -1)
         return i;
   }
   return -1;
}

void mutex_init(struct mutex_t* m) {
   int8_t i;

   m->owner = 0;
   for (i = 0; i < 10; i++)
      m->waitlist[i] = -1;
}

void mutex_lock(struct mutex_t* m) {
   int8_t i, j;
   uint8_t cur = get_thread_id();;

   if (m->owner != 0) {
      i = find_next_index(cur, m->waitlist);
      m->waitlist[i] = cur;

      //thread -> waiting
      sysArray.array[cur].state = THREAD_WAITING;
      yield();
   }
   else {
      m->owner = cur;
   }
}

void mutex_unlock(struct mutex_t* m) {
   int8_t i;
   uint8_t next = m->waitlist[0];
   uint8_t size = sizeof(m->waitlist)/sizeof(m->waitlist[0]);
   
   //move threads on the waitlist up
   for (i = 0; i < size-1; i++) 
      m->waitlist[i] = m->waitlist[i+1];

   m->owner = next;
   //next thread -> ready
   sysArray.array[next].state = THREAD_READY;
}

void sem_init(struct semaphore_t* s, uint8_t value) {
   int8_t i;
   s->value = value;

   for (i = 0; i < 10; i++) 
      s->waitlist[i] = -1;
}

void sem_wait(struct semaphore_t* s) {
   int8_t x, i;

   s->value -= 1;
   x = s->value;

   if (x < 0) {
      uint8_t cur = get_thread_id();
      i = find_next_index(cur, s->waitlist);
      s->waitlist[i] = cur;

      //thread -> waiting
      sysArray.array[cur].state = THREAD_WAITING;
      yield();
   }
}

void sem_signal(struct semaphore_t* s) {
   int8_t i;
   uint8_t next = s->waitlist[0];
   uint8_t size = sizeof(s->waitlist)/sizeof(s->waitlist[0]);
   
   //move threads on the waitlist up
   for (i = 0; i < size-1; i++) 
      s->waitlist[i] = s->waitlist[i+1];
   
   s->value += 1;
   //next thread -> ready
   sysArray.array[next].state = THREAD_READY;
}

void sem_signal_swap(struct semaphore_t* s) {
   int8_t i;
   uint8_t next = s->waitlist[0];
   uint8_t size = sizeof(s->waitlist)/sizeof(s->waitlist[0]);
   
   //move threads on the waitlist up
   for (i = 0; i < size-1; i++) 
      s->waitlist[i] = s->waitlist[i+1];
   
   s->value += 1;
   //next thread -> ready
   sysArray.array[next].state = THREAD_READY;
   sysArray.array[next].sched_count++;

   context_switch((uint16_t*)&sysArray.array[next].stackPtr, 
    (uint16_t*)&sysArray.array[get_thread_id()].stackPtr);
}
