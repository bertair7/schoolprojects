//Global defines
#ifndef GLOBALS_H
#define GLOBALS_H

#define RED 31
#define GREEN 32
#define YELLOW 33
#define BLUE 34
#define MAGENTA 35
#define CYAN 36
#define WHITE 37

#define THREAD_RUNNING 100
#define THREAD_READY 101
#define THREAD_SLEEPING 102
#define THREAD_WAITING 103

void serial_init();
uint8_t byte_available();
uint8_t read_byte();
uint8_t write_byte(uint8_t b);
void print_string(uint8_t* s);
void print_int(uint16_t i);
void print_int32(uint32_t i);
void print_hex(uint16_t i);
void print_hex32(uint32_t i);
void set_cursor(uint8_t row, uint8_t col);
void set_color(uint8_t color);
void clear_screen(void);
void print_state(uint8_t state);

//place defines and prototypes here
typedef struct thread_t {
   uint8_t thread_id;
   char name[10];
   uint16_t func;
   uint8_t *stack;
   uint8_t *stackPtr;
   uint8_t *stackBase;
   uint16_t size;
   uint16_t sched_count;
   uint8_t state;
   uint16_t sleepTime;
} thread_t;

typedef struct system_t {
   thread_t array[8];
   uint8_t threadsUsed;
   uint8_t currThread;
   uint16_t num_interrupts;
} system_t;

typedef struct mutex_t {
   uint8_t owner; 
   uint8_t waitlist[10];
} mutex_t;

typedef struct semaphore_t {
   uint8_t value;
   uint8_t waitlist[10];
} semaphore_t;

#endif
